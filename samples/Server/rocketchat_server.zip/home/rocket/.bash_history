cd rocketchat-compose
grep -E "PORT|BIND" .env
echo "BIND_IP=0.0.0.0" >> .env
echo "HOST_PORT=3000" >> .env
sudo docker compose -f compose.database.yml -f compose.yml up -d
sudo docker compose -f compose.database.yml -f compose.yml ps
grep -n -A3 "ports" compose.yml
curl -sI https://cloud.rocket.chat | head -3
sudo docker compose -f compose.database.yml -f compose.yml logs --tail 30 rocketchat
grep -l "nats" *.yml
sudo docker compose -f compose.database.yml -f compose.nats.yml -f compose.yml up -d
sudo docker compose -f compose.database.yml -f compose.nats.yml -f compose.yml exec mongodb mongosh rocketchat --quiet --eval 'db.rocketchat_settings.updateOne({_id:"Show_Setup_Wizard"},{$set:{value:"completed"}})'
sudo docker compose -f compose.database.yml -f compose.nats.yml -f compose.yml restart rocketchat
sudo docker compose -f compose.database.yml -f compose.nats.yml -f compose.yml exec mongodb mongosh rocketchat --quiet --eval 'db.rocketchat_settings.updateOne({_id:"Show_Setup_Wizard"},{$set:{value:"in_progress"}})'
sudo docker compose -f compose.database.yml -f compose.nats.yml -f compose.yml restart rocketchat
