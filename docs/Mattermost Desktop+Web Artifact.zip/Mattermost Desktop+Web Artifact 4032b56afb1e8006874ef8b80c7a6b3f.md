# Mattermost Desktop+Web Artifact

Status: Completed (Pending Additions)

## Mattermost란?

Mattermost는 자체 호스팅 팀 메신저이다. 서버 중심 구조로 메시지 원본과 파일, 세션을 서버의 PostgreSQL과 파일 저장소가 보관하고, 클라이언트(Electron 데스크톱 앱과 웹 브라우저)는 서버에서 받아 화면에 보여 준다. 서버는 Go로 작성된 단일 바이너리이며 PostgreSQL 또는 MySQL을 사용한다.  종단간 암호화(E2EE)가 없기 때문에 서버 관리자나 서버 디스크를 가진 사람은 Private 채널과 DM까지 모두 평문으로 읽을 수 있다.

### **주요 특징**

- **서버 중심 구조 (Server-centric)** : 메시지 정본과 파일을 서버가 보관하므로, 서버 DB 하나에 조직 전체 대화가 평문으로 남는다.
- **종단간 암호화 없음 (No E2EE)** : Private 채널과 DM도 서버에 평문으로 저장돼, 서버 디스크를 가진 사람이 전부 읽을 수 있다.
- **Go 단일 바이너리 + 관계형 DB (PostgreSQL/MySQL)** : 최신버전 에서는 PostgreSQL 17을 쓰고, 클러스터 heap 파일에서 직접 메시지가 복원된다.
- **Electron 데스크톱 앱 (Electron)** : Chromium 기반이라 LevelDB, IndexedDB, Chromium HTTP 캐시에 상태와 대화 일부가 남는다.
- **웹 클라이언트 (Web)** : 브라우저 History, Cookies, Cache에 접속 이력과 받은 대화 일부가 남는다.

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Desktop 앱 config schema v4, Web은 Chrome 155.0.8059.85 |
| 설치 방식 | Desktop 설치형(Program Files\Mattermost), Web은 Chrome 탭 |
| OS / 버전 | Windows 11 |
| 저장소 | NTFS 볼륨 |
| 샘플 수집 방법 | FTK Imager로 오프라인(dead) 디스크 이미징(E01). 클라이언트 2대 |
| 계정 | alex (Desktop), natasha (Web) |

## 아티팩트 경로 및 설명(**Mattermost Desktop**)

Electron 데스크톱 앱에서 확인 할 경로는 아래와 같다. 서버 주소는 config.json에 평문으로 남고, 인증 토큰은 OS 암호화로 보호돼 쿠키에 암호문으로만 남으며, 로그인과 채널 방문 같은 사용자 상태와 작성 중이던 드래프트는 LevelDB에, 주고받은 메시지의 일부는 HTTP 캐시에 평문으로 남는다. 각 경로는 뒤에서 차례대로 분석한다.

| 파일 경로 | 설명 |
| --- | --- |
| C:\Users\user\AppData\Roaming\Mattermost\config.json | 접속했던 서버의 목록이 평문으로 들어 있다. 서버 이름과 URL, 마지막으로 활성화한 서버, 다운로드 폴더 경로를 확인할 수 있다. |
| C:\Users\user\AppData\Roaming\Mattermost\Local Storage\leveldb\[0-9]{6}.log | 로그인 흔적과 화면 상태가 평문으로 남는다. 로그인 이력, 마지막으로 사용한 팀, 방문한 채널 이력이 저장되고 origin 키에 서버 주소가 보인다. 평문 토큰은 없다. |
| C:\Users\user\AppData\Roaming\Mattermost\IndexedDB\http_192.168.156.134_8065.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb | 작성 중이던 드래프트가 채널별로 저장된다. 입력하던 메시지 텍스트와 작성 시간이 남아, 보낸 메시지가 서버에만 있어도 사용자가 무엇을 썼는지 복원된다.` |
| C:\Users\user\AppData\Roaming\Mattermost\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index | 서버 API 응답이 캐시된다. GET으로 조회된 메시지 응답이 평문 또는 gzip으로 들어 있어, 상대가 보낸 수신 메시지까지 본문이 복원된다. |
| C:\Users\user\AppData\Roaming\Mattermost\Network\Cookies | 인증에 쓰이는 쿠키가 저장된다. MMAUTHTOKEN 등 값은 OS 암호화로 보호돼 암호문으로만 남는다.(유효기간은 약 30일) |

### config.json 분석

접속했던 서버의 이름과 URL이 servers 배열에 평문으로 저장되어 있으며, 마지막으로 활성화한 서버와 다운로드 폴더 경로도 확인해 볼 수 있다. 구버전에서는 teams 키를 사용했으나 최신 버전에서는 servers 키를 사용한다.

```jsx
{ "version": 4,
  "servers": [ { "name": "RESEARCH", "url": "http://192.168.156.134:8065/", "order": 0 } ],
  "lastActiveServer": 0, "downloadLocation": "C:\\Users\\user\\Downloads" }
```

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| servers[].name / url | 접속 서버 이름과 주소 | RESEARCH, http://192.168.156.134:8065/ |
| lastActiveServer | 마지막으로 활성화한 서버 번호 | 0 |
| downloadLocation | 다운로드 폴더 경로 | C:\Users\user\Downloads |

### Local Storage\leveldb\[0-9]{6}.log 분석

로그인 세션이 평문으로 저장되어 있으며 흔적과 화면 상태를 확인할 수 있다. 또한 접속 서버 내 어떤 채널에 접속했었는지에 대한 채널 이름 정보도 존재한다. 오류 소스코드를 수정한 ccl_chromium_reader 수정버전을 이용하여 leveldb 파일을 분석해 보면 아래와 같다.

![image.png](image.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| was_logged_in | 로그인 이력 | true |
| user_prev_team:<userid> | 마지막 사용 팀 | 팀 ID |
| user_team_prev_channel:... | 방문 채널 이력 | town-square, private-room, DM ID 등 |

로그인 여부, 마지막으로 쓰던 팀, town-square와 비공개 방과 DM을 오간 채널 방문 순서가 평문으로 남는다

### IndexedDB\http_192.168.156.134_8065.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb 분석

작성 중이던 드래프트가 채널별로 draft_<channelID> 키에 저장되고, 입력하던 메시지 텍스트와 작성 시각이 그대로 남는다. 보낸 메시지가 서버에만 있어도 사용자가 무엇을 쓰고 있었는지는 이 드래프트로 복원이 된다. 드래프트가 담는 범위는 뒤의 캐시와 드래프트에 남는 대화에서 HTTP 캐시와 묶어 자세히 본다.

![image.png](image%201.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| draft_<channelID> | 작성 중이던 드래프트 | 메시지 텍스트, 작성 시각 |

### Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index 분석

Chromium 블록파일 캐시방식을 사용한다. GET으로 조회된 서버 API 응답(/api/v4/posts/..., /api/v4/channels/.../posts 등)의 본문이 평문 JSON 또는 gzip으로 저장되며 암호화는 없다. Chromium 캐시 분석 도구인 ChromeCacheView를 이용해서 분석을 진행해 보면 아래와 같다.

![image.png](image%202.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| 캐시 엔트리 key | 캐시된 요청 URL | /api/v4/posts/<Posts ID>/ , /api/v4/channels/<Channel ID>/ , /api/v4/emoji/<Emoji ID>/ , /api/v4/files/<File ID>/ , /api/v4/teams/<Team ID>/ |
| 엔트리 creation_time | 응답을 받은 시각 | WebKit µs, KST 변환 |
| 응답 본문 (posts) | 메시지 본문, 작성자, 채널, 시각 | JSON 평문 또는 gzip |

### Network\Cookies 분석

인증에 쓰이는 쿠키가 Chromium 쿠키 SQLite에 저장된다. MMAUTHTOKEN, MMCSRF, MMUSERID 세 쿠키가 있고 값은 모두 OS 암호화로 보호돼 암호문으로만 남는다. main.log에 SecureStorage 초기화 기록이 있어 비밀값은 OS 암호화 저장을 쓴다.

세 쿠키는 모두 영속 쿠키이며 같은 만료시각을 가진다. 생성은 2026-10-23 03:22:47 KST, 만료는 2026-11-22 23:26:54 KST로 유효기간은 약 30일이다. 이 만료시각은 서버 sessions 테이블의 세션 만료값과 초 단위까지 일치해, 쿠키 수명이 서버 세션 길이를 그대로 따른다는 것을 보여준다.

![image.png](image%203.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| MMAUTHTOKEN | 인증 토큰 (암호문) | 89바이트, httponly |
| MMCSRF | CSRF 방어 토큰 (암호문) | 89바이트 |
| MMUSERID | 사용자 ID (암호문) | 89바이트 |
| 공통 만료 | 세 쿠키의 유효기간 | 약 30일, 서버 세션과 일치 |

그렇기 때문에 세션이 끊기지 않은 상태에서 서버만 연결 되어 있다면 해당 폴더를 분석 PC의 mattermost 아티팩트 폴더 경로로 대체 했을때 mattermost 사용자로 하여 접속할 수 있다.

![image.png](image%204.png)

## 아티팩트 경로 및 설명(**Mattermost Web**)

Mattermost는 Desktop 뿐만 아니라 Web으로도 접속 가능한 애플리케이션이다. 서버 접속 이력은 브라우저 History가, 인증 토큰은 Cookies가 암호문으로, 작성 중이던 드래프트는 IndexedDB가 가지며, 주고받은 메시지의 일부는 HTTP 캐시에 평문으로 남는다. Desktop과 겹치는 저장소는 구조가 같고, 여기에 브라우저 History가 더해지는 점이 다르다.

| 파일 경로 | 설명 |
| --- | --- |
| C:\Users\user\AppData\Local\Google\Chrome\User Data\Default\History | 접속한 서버 URL과 팀 이름, 방문한 채널과 DM 상대, 방문 횟수, 마지막 방문 시각이 그대로 남는다. 이름이 바뀐 채널은 제목에 바뀐 이름이 반영돼 변경 시점을 가늠할 수 있다. |
| C:\Users\user\AppData\Local\Google\Chrome\User Data\Default\Local Storage\leveldb\[0-9]{6}.log | 로그인 흔적과 화면 상태가 평문으로 남는다. 로그인 이력, 마지막으로 사용한 팀, 방문한 채널 이력이 저장되고 origin 키에 서버 주소가 보인다. 평문 토큰은 없다. |
| C:\Users\user\AppData\Local\Google\Chrome\User Data\Default\IndexedDB\http_192.168.156.134_8065.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb | 작성 중이던 드래프트가 채널별로 저장된다. 입력하던 메시지 텍스트와 작성 시간이 남아, 보낸 메시지가 서버에만 있어도 사용자가 무엇을 썼는지 복원된다.` |
| C:\Users\user\AppData\Local\Google\Chrome\User Data\Default\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index | 서버 API 응답이 캐시된다. GET으로 조회된 메시지 응답이 평문 또는 gzip으로 들어 있어, 상대가 보낸 수신 메시지까지 본문이 복원된다. |
| C:\Users\user\AppData\Local\Google\Chrome\User Data\Default\Network\Cookies | 인증에 쓰이는 쿠키가 저장된다. MMAUTHTOKEN 등 값은 OS 암호화로 보호돼 암호문으로만 남는다.(유효기간은 약 30일) |

### History 분석

브라우저 방문 기록 SQLite이다. Web 클라이언트는 앱 화면 이동이 URL로 드러나기 때문에, Desktop에는 없는 접속 타임라인이 여기 통째로 남는다. urls 테이블에 접속한 서버 주소와 팀 이름(research), 방문한 채널과 DM 상대(@alex), 방문 횟수, 마지막 방문 시각이 그대로 기록된다. 파일 이름이 바뀐 채널은 제목에 바뀐 이름(documents)이 반영돼 있어 변경 시점 전후를 가늠할 수 있다.

![image.png](image%205.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| urls.url / title | 접속한 서버 URL과 채널, 제목 | /research/channels/town-square 등 |
| urls.visit_count | 방문 횟수 | 정수 |
| urls.last_visit_time | 마지막 방문 시각 | WebKit µs |

### Local Storage\leveldb\[0-9]{6}.log 분석

Desktop 앱과 동일하다.

### IndexedDB\http_192.168.156.134_8065.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb 분석

Desktop 앱과 동일하다.

### Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index 분석

Desktop 앱과 동일하다.

### Network\Cookies 분석

Desktop 앱과 동일하다.