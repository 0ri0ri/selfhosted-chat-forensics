# Rocket.Chat Desktop Artifact

## Rocket.Chat 이란?

Rocket.Chat은 직접 서버를 운영하는 오픈소스 메신저다. 데스크톱 앱은 Electron으로 만들어졌고, 메인 창 안에 서버마다 웹뷰를 하나씩 띄워 서버의 웹 앱(Meteor)을 그대로 실행한다. 웹뷰마다 서버 주소로 이름을 지은 별도 세션 파티션을 사용하기 때문에, 서버마다 독립된 Chromium 프로필 폴더가 생긴다. 종단간 암호화(E2EE)는 방마다 켜는 선택 기능이라, E2EE를 켜지 않은 방은 DM까지 서버에 평문으로 남는다. E2EE 방은 서버에 암호문만 남지만, 이를 푸는 개인키가 클라이언트에 평문으로 남는다. 앱 자체 설정(서버 목록, 창 상태, 신뢰한 인증서)은 앱 공통 폴더의 config.json에 저장되고, 대화와 관련된 데이터는 서버별 파티션의 IndexedDB와 Local Storage에 쌓인다.

### **주요 특징**

- **서버별 파티션 (Session Partition)** : 서버마다 Partitions\https%3A\<호스트> 폴더가 생기고 그 안에 IndexedDB, Local Storage, Cache가 따로 남는다.
- **캐시 컬렉션 (CachedCollection)** : 방, 구독, 권한, 공개 설정을 localForage로 IndexedDB에 저장한다. 메시지는 캐시하지 않는다.
- **종단간 암호화 (E2E Encryption)** : 사용자 RSA 키쌍과 방별 AES 키를 사용하며, 키쌍은 Local Storage에 JSON 문자열로 남는다.

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Rocket.Chat Desktop 4.18.5 (Electron), 접속 서버 Rocket.Chat 8.9.0 |
| 설치 방식 | 사용자 단위 설치형 (%LOCALAPPDATA%\Programs\Rocket.Chat, HKCU Uninstall 키) |
| OS / 버전 | Windows 10 Pro 25H2, 빌드 26200.9168, 시간대 Korea Standard Time, 컴퓨터 이름 USER-PC |
| 샘플 수집 방법 | VM의 VMDK를 FTK Imager로 E01 변환 (EWF header의 수집 프로그램 ADI8.2.0.59). |
| 계정 | OS 계정 user. Rocket.Chat 테스트 계정 rocket02 (일반 사용자), 대화 상대 rocket01 |

## 아티팩트 경로 및 설명(**Rocket.Chat Desktop**)

Rocket.Chat 데스크톱을 사용한 흔적은 %AppData%/Rocket.Chat에 존재한다. 아래의 경로에서 사용자의 흔적을 확인할 수 있다.

| 파일 경로 | 설명 |
| --- | --- |
| C:\Users\user\AppData\Roaming\Rocket.Chat\config.json | 등록한 서버의 URL과 이름, 서버 버전, 로그인 여부, 마지막으로 본 화면, 사용자가 신뢰한 서버 인증서, 창 상태가 평문 JSON으로 남는다. 이 샘플에서는 사용 중 레코드가 없어 삭제된 MFT 레코드 3개와 $LogFile에서 이전 판을 찾아 읽었다. |
| C:\Users\user\AppData\Roaming\Rocket.Chat\logs\main.log, errors.jsonl | 앱 시작, 서버 연결 때의 인증서 오류, 클립보드 쓰기 같은 이벤트가 로컬 시각(KST)으로 기록된다. errors.jsonl에는 렌더러 오류가 UTC로 남는다. 앱을 언제 시작했는지 판단하는 근거가 된다. |
| C:\Users\user\AppData\Roaming\Rocket.Chat\Local State, Preferences, Network | Chromium 공통 설정 파일이다. DPAPI로 보호한 쿠키 암호화 키, 첫 실행 시각, 맞춤법 언어, PC의 로컬 IP가 남는다. |
| C:\Users\user\AppData\Roaming\Rocket.Chat\Partitions\https%3A\192.168.6.133\IndexedDB\https_192.168.6.133_0.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb | 서버 웹 앱이 localforage로 만든 캐시로, 방 목록과 구독, 권한, 공개 설정이 LevelDB에 저장된다. 새 메시지가 올 때마다 이전 판이 그대로 남아, 판마다 들어 있는 lastMessage를 모으면 메시지 이력과 E2E 메시지의 복호 평문, 서버에서 지운 첨부까지 확인할 수 있다. |
| C:\Users\user\AppData\Roaming\Rocket.Chat\Partitions\https%3A\192.168.6.133\Local Storage\leveldb\[0-9]{6}.log or [0-9]{6}.ldb | 로그인 토큰, 사용자 ID, E2E 개인키와 공개키(JWK)가 평문으로 저장된다. 사용자가 지운 E2E 복구 비밀번호와 입력창 초안 키도 LevelDB 로그에 남아, 서버 DB와 결합하면 E2E 메시지를 복호할 수 있다. |
| C:\Users\user\AppData\Roaming\Rocket.Chat\Partitions\https%3A\192.168.6.133\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index | 서버별 HTTP 캐시다. 사용자가 앱에서 서버 인증서를 신뢰한 상태라 응답을 디스크에 캐시하지 않은 것으로 보이며, 이 샘플에서는 엔트리가 0개였다. |

### **Rocket.Chat\config.json 분석**

json 파일에는 평문으로 앱 설정이 저장되어 있다.

| 테이블/키 | 필드 | 의미 | 샘플 값 (10-24 판 → 10-25 판) |
| --- | --- | --- | --- |
| servers[0] | url, title, version | 등록 서버와 서버 버전 | https://192.168.6.133/, Rocket Test, 8.9.0 |
| servers[0] | userLoggedIn, userRoles | 로그인 여부, 역할 | true, user |
| servers[0] | lastPath, pageTitle | 마지막으로 본 화면 | /home → /group/Trip |
| servers[0] | presence | 상태 | away → online |
| servers[0] | supportedVersionsValidatedAt, Source | 지원 버전 확인 시각 | 2026-10-24T09:35:27.033Z builtin → 2026-10-25T05:32:00.370Z cloud |
| servers[0] | favicon, badge | 서버 아이콘(data URL), 안 읽은 수 | PNG, 0 |
| trustedCertificates | 192.168.6.133 | 사용자가 신뢰한 서버 인증서 (PEM) | Caddy Local Authority - ECC Intermediate. 두 판의 인증서가 다르다 (Caddy가 중간 인증서를 다시 발급) |
| mainWindowTitle |  | 창 제목 | Home - Rocket Test → Trip - Rocket Test |
| secondaryWindowStates | documentViewer | 문서 보기 창 위치 | 없음 → x 327 y 166 1065x541 |
| downloads |  | 앱이 받은 파일 | {} (없음) |
| __internal__.migrations.version |  | 설정 형식 버전 | 4.18.5 |

### Rocket.Chat\logs\main.log, errors.jsonl 분석

| 테이블/키 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| main.log | 줄 머리 [YYYY-MM-DD HH:MM:SS.mmm] | 로컬 시각(KST). 18:34:08.871이 MFT의 앱 폴더 생성 09:34:08.825 UTC와 맞다 | 이벤트 10줄 (5,521줄 대부분은 스택) |
| main.log | Starting Rocket.Chat Desktop application | 앱 시작, 버전, userData 경로 | 2026-10-24 18:34:08.871 한 번뿐 |
| main.log | Error fetching unique ID for server | 서버 연결 때 인증서 오류 | 10-24 18:35:27, 10-25 14:31:51, 14:32:00 |
| main.log | Accessing 'clipboard.writeText' | 렌더러가 클립보드에 썼다 | 10-24 18:38:08 |
| errors.jsonl | timestamp (UTC ISO) | 렌더러 오류 | 2026-10-24T10:05:30.932Z 2건 |

### **Rocket.Chat\logs, Local State, Network 분석**

| 테이블/키 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| Local State | os_crypt.encrypted_key | DPAPI로 보호한 Chromium 키 (쿠키, 비밀번호용) | 283 B, 'DPAPI' 접두사 |
| Local State | uninstall_metrics.installation_date2 | 첫 실행 (Unix 초) | 1792834448 = 2026-10-24T09:34:08Z |
| Preferences | spellcheck.dictionaries | 맞춤법 언어 | ko |
| Network Persistent State | supports_quic.address | 로컬 IP | 192.168.6.132 |
| Network\Cookies | cookies | 쿠키 | 0행 |

### **Rocket.Chat**\Partitions\https%3A\192.168.6.133\IndexedDB\https_192.168.6.133_0.indexeddb.leveldb\[0-9]{6}.log or [0-9]{6}.ldb

서버의 웹 앱의 IndexedDB이며, 데이터 베이스는 2개이다. MeteorDynamicImportCache는 동적 import한 소스 코드 캐시이고, https[:]//192.168.6.133/ 은 localforage가 만든 데이터 베이스이다. 데이터 베이스 내 중요한 키값은 3개이다.

- **rooms :** 방 정보(방 이름, 참여자, 메시지 수, 생성 시각)와 각 방의 마지막 메시지. 암호화 방의 메시지는 암호문으로 남아 있다.
- **subscriptions :** 로그인 사용자(rocket02)가 참여한 방 정보와 각 방의 마지막 메시지. 암호화 방의 메시지도 복호화된 평문으로 남아 있다.
- **public-settings :** 서버 이름, E2E 사용 여부, 메시지 삭제 허용 여부 같은 서버 설정.

rooms 에 E2EE가 적용된 암호화된 대화내용 및 첨부 파일과 E2EE가 적용되지 않은 일반 대화내용 및 첨부파일 정보가 저장되어 있고, subscriptions 키로 인해 암호화된 데이터도 한번에 복호화 되어 출력이 된다. 오류 소스코드를 수정한 ccl_chromium_reader 수정버전을 이용하여 leveldb 파일을 분석해 보면 아래와 같다.

![image.png](image.png)

rooms와 subscriptions 값의 token은 로그인 토큰과 같은 43자 문자열로 되어 있으며, 데이터 베이스 내 각 테이블에서 확인가능한 데이터는 아래와 같다.

| 테이블/키 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| keyvaluepairs / rooms | records[] | 방 문서: _id, t(d = DM, p = 비공개), usernames, msgs, e2eKeyId, encrypted, topic, lastMessage | DM 1, Trip(p, encrypted, topic small talk) 1 |
| keyvaluepairs / subscriptions | records[] | 구독 문서: rid, name, fname, unread, alert, ls(마지막으로 읽은 시각), E2EKey, lastMessage | 2건 |
| keyvaluepairs / permissions | records[] | 권한 표 | 최신 판 updatedAt 2026-10-25 |
| keyvaluepairs / public-settings | records[] | 공개 설정 | E2E_Enable true, E2E_Enable_Encrypt_Files true |
| 모든 판 | token | Meteor 로그인 토큰 | ****(43자) |
| 판 수 |  | 키 4개에 레코드 46개 (최신 4, 이전 값 42) | rooms 20, subscriptions 21, permissions 3, public-settings 2 |

### Partitions\https%3A\192.168.6.133\Local Storage\leveldb\[0-9]{6}.log or [0-9]{6}.ldb 분석

local storage의 leveldb에는 연결된 서버의 정보, 로그인 토큰, 토큰 만료 시각, 사용자 ID, E2E 복구 비밀번호, E2E 개인키, E2E 공개키 등이 존재하며 개인키가 평문으로 저장되어 있기 때문에 E2EE 암호화 대화방에 대한 복호화가 가능해 진다.

![image.png](image%201.png)

### Partitions\https%3A\192.168.6.133\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index 분석

Chromium 블록파일 캐시방식을 사용한다. 정적 자원(JS, CSS, 폰트, 이미지 등)과 사용자 아바타(user_avatars 경)가 존재한다. 대화방에서 업로드 및 다운로드한 첨부파일의 원본 파일도 존재한다. Chromium 캐시 분석 도구인 ChromeCacheView를 이용해서 분석을 진행해 보면 아래와 같다.

![image.png](image%202.png)

## 복호화를 위한 설명 및 복호화 방법론

### 각 키 및 복호화 대상 설명

```jsx
- 개인키 : Local Storage의 000003.log
- 방키 : 방키 데이터 base64 decode 하면 암호화된 방키가 나오고 그걸 개인키로 복호화(RSA-OAEP(SHA-256))를 하면 복호화 해제된 방키(AES 256 GCM)가 나옴.
- 메시지 : 메시지 암호문을 aes 256 gcm로 iv 와 방키로 복호화 하면 나옴
- 첨부파일 : 첨부파일 메시지를 방키로 복호화(AES-256-CTR)를 한후 나온 데이터에 IV와 키와 암호화방식이 존재하고 해당 값을 이용해서 복호화를 하면 첨부파일 나옴.
```

### 방키 복호화 하는 방법

준비물 : jwk.json, dec.py, 방키값[36:]

1. 개인키가 담긴 jwk 객체를 jwk.json 파일에 저장한다.
    - **jwk.json**
        
        ```json
        {"alg":"RSA-OAEP-256","d":"ICk8Dn0fAfUpi4Q_Rs1pjT8XX7hWpN6hBz3byvQT_yg33f2cQAWDXREOYsoGPAizuEac87zkcml0DMiPyb8-DWgeya59UA3-BPfTvOH5ZQV4vRJ9_M4Ncod0fytegdZ-6AKkBbV2CQ_wHHb2_CrMh0RCAHoRHGA9u9WEs8jyoJcUvwnxPDzct3k1ZPIKtNvnQD8mZKrBKJd15bFp3K483f1CtCvLKgtZlBlAue02pYdBYhmpDNrIMu1tLt-8fDNThM4EizWLnMWgrIX6ZUa5DNdXkJQjMAIQNhiVwjb07ypCmCYIeVnGQdzxj8UIampddjrRdvPpbrzLspP29v32yQ","dp":"mhtaUUXYOf-TIcW8Vx_-Qt9hpyC_BXe9Osj8kibKZ34XPSEL8R8vwIOHJJpDKCeEDu6vy5OKMNpsw5KJUZAKZHPvSDApMx2n24fAa0lTzJjx40pPgQUqpBc8VNqTwxF4cXWNpyQMpk2o_frpzO-UXPfvUrT5z6S6umJqAFeSjG0","dq":"p5s6ijNMrXKnP-ON4zwUmukq8IDIATuNX2Gw0ZmOG7sOFd1DUC5a50Q7mWm9_j6ILhIoq8LW8b7-PQVLSaTdY8MLwH5oB4Wdl6XUi1GFigvlf1Vbi4reK4d10j6stw0Oh4at_u25vYsuYJdTVdiJJcBXQd8WQECkfVxw1z0Sbw","e":"AQAB","ext":true,"key_ops":["decrypt"],"kty":"RSA","n":"tiAq_vyEFT1I5uOBGJdPzZRgJ0eRVgKm9lpc4S7wQWSPY69xUJ-yMW0m_rQ3Qhgxv5e1BPlB4aYGMu9Py5jqDHrRKqeEn8hkDMg__PDl2oC8WHb8u5UTR5-10mJ5HTL1uaWd1lBKpV810_W5U_yQiVdWZYjOTh13hLpxaxPOkp1Q2WUzRsdH7z0C49_LGx8M7wzHrIS1X7-oTPwvxYLn4wlfmzZQl4q1SVLM7ne6i7RI2Baj8dYHeNivwMrCMnOfmEcngD2cK3tQBDQvdvV44Mm8YpNTwUxav5QTNZYYJMsB9OfjxHWmtrp7bTRqxv9BmC4Gk401EZIyvP7Je9jBmw","p":"53K2NTv7nGJgoWgOY9DjQ8NFsS3QIUSaHj_WG4izUc_3_k_luv3-Lfpgt5vYJResQ1dLCn3NNZ5IstsxQyOmpKRDQVU1YDMIgfRHPPVJwpTNhPqc_11OVQSMkFW_407TjesfGlJUkx-6a5Sv7RggCOU-hh-fuKdgMGrwNKrsFT0","q":"yXIJym5hNJQ6h0MRwnNXi2hKViO4f2pvTNc2U0dcMZ7YHfMysTWvk2BQXVIjV7iEt2j4en7PkiGTz_ED-eqMqQQhEXmUdbKnMsugFJxSwi9lnIU78qjCW9HiX8u2oyAtKsQoSguvE426MjSGhZ1KgiXYWTGw0ryRHg0jGNqjD7c","qi":"TJn5GOhYwHQ2PNu5lGStHamveghogvDnyzGSwdb3I1FZokYehswT_vHKqQH3F0PSForl5nyWb2aJOKCLWVFIdUt1QDGU_3aK1HKu4V6dKATL6iGm499hvCN2nGdMMlVM9JLIgumfH1qmBiw8yw9gj79UZIUPfXuNetC5zHtxu_4"}
        ```
        
2. 아래와 같은 암호화된 방키값을 찾는다.
    
    ```json
    61a76f88-caef-409d-9440-008ebaf009adNSpYmSAxBvTQNNlpfzHXbPOzvEfbEknrRbsXowTWwuuMkzE6DVWtW9Uif8B/EON20mrS9lE2Fx0SHCnF0/zUWnt2lfZDyMOzJzSMjBMklkds5s090obucL9Z+6pmpRdJBUykWyGGj8OJfmPMY8+43y6HjX1V8vP4FIpgRpokmHQ+P3NYaY3rYYaKcFeemaODNQEyVAvoeOzAXBIHy8uvVY/GdzRGDLsRMAHwcBo+FwXKndpOJQlc/nJVMLA/bNJfOZ61j2HSMRProJD7KUzKNQsmW6OLSMvchyCfx4gzAFYTe8HSYEvn2PG81h17JuXIVEfg5n4t/XpYdrboZPjJzQ==
    ```
    
3. 암호화된 방키값에서 앞 36글자(61a76f88-caef-409d-9440-008ebaf009ad)를 제거한후 base64 decode를 진행한다.
    
    [CyberChef](https://gchq.github.io/CyberChef/#recipe=From_Base64('A-Za-z0-9%2B/%3D',true,false)&input=TlNwWW1TQXhCdlRRTk5scGZ6SFhiUE96dkVmYkVrbnJSYnNYb3dUV3d1dU1rekU2RFZXdFc5VWlmOEIvRU9OMjBtclM5bEUyRngwU0hDbkYwL3pVV250MmxmWkR5TU96SnpTTWpCTWtsa2RzNXMwOTBvYnVjTDlaKzZwbXBSZEpCVXlrV3lHR2o4T0pmbVBNWTgrNDN5NkhqWDFWOHZQNEZJcGdScG9rbUhRK1AzTllhWTNyWVlhS2NGZWVtYU9ETlFFeVZBdm9lT3pBWEJJSHk4dXZWWS9HZHpSR0RMc1JNQUh3Y0JvK0Z3WEtuZHBPSlFsYy9uSlZNTEEvYk5KZk9aNjFqMkhTTVJQcm9KRDdLVXpLTlFzbVc2T0xTTXZjaHlDZng0Z3pBRllUZThIU1lFdm4yUEc4MWgxN0p1WElWRWZnNW40dC9YcFlkcmJvWlBqSnpRPT0&oeol=VT)
    
4. jwk.json 파일과 [dec.py](http://dec.py) 파일을 준비해서 dec.py를 실행하여 key.pem 파일을 획득한다.
    - **dec.py**
        
        ```python
        import base64, json
        from cryptography.hazmat.primitives.asymmetric import rsa, padding
        from cryptography.hazmat.primitives import hashes, serialization
        j=json.loads(open('jwk.json').read())
        b=lambda s:int.from_bytes(base64.urlsafe_b64decode(s+'='*(-len(s)%4)),'big')
        k=rsa.RSAPrivateNumbers(b(j['p']),b(j['q']),b(j['d']),b(j['dp']),b(j['dq']),b(j['qi']),rsa.RSAPublicNumbers(b(j['e']),b(j['n']))).private_key()
        open('key.pem','wb').write(k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
        ```
        
    - **key.pem**
        
        ```python
        -----BEGIN RSA PRIVATE KEY-----
        MIIEowIBAAKCAQEAtiAq/vyEFT1I5uOBGJdPzZRgJ0eRVgKm9lpc4S7wQWSPY69x
        UJ+yMW0m/rQ3Qhgxv5e1BPlB4aYGMu9Py5jqDHrRKqeEn8hkDMg//PDl2oC8WHb8
        u5UTR5+10mJ5HTL1uaWd1lBKpV810/W5U/yQiVdWZYjOTh13hLpxaxPOkp1Q2WUz
        RsdH7z0C49/LGx8M7wzHrIS1X7+oTPwvxYLn4wlfmzZQl4q1SVLM7ne6i7RI2Baj
        8dYHeNivwMrCMnOfmEcngD2cK3tQBDQvdvV44Mm8YpNTwUxav5QTNZYYJMsB9Ofj
        xHWmtrp7bTRqxv9BmC4Gk401EZIyvP7Je9jBmwIDAQABAoIBACApPA59HwH1KYuE
        P0bNaY0/F1+4VqTeoQc928r0E/8oN939nEAFg10RDmLKBjwIs7hGnPO85HJpdAzI
        j8m/Pg1oHsmufVAN/gT307zh+WUFeL0SffzODXKHdH8rXoHWfugCpAW1dgkP8Bx2
        9vwqzIdEQgB6ERxgPbvVhLPI8qCXFL8J8Tw83Ld5NWTyCrTb50A/JmSqwSiXdeWx
        adyuPN39QrQryyoLWZQZQLntNqWHQWIZqQzayDLtbS7fvHwzU4TOBIs1i5zFoKyF
        +mVGuQzXV5CUIzACEDYYlcI29O8qQpgmCHlZxkHc8Y/FCGpqXXY60Xbz6W68y7KT
        9vb99skCgYEA53K2NTv7nGJgoWgOY9DjQ8NFsS3QIUSaHj/WG4izUc/3/k/luv3+
        Lfpgt5vYJResQ1dLCn3NNZ5IstsxQyOmpKRDQVU1YDMIgfRHPPVJwpTNhPqc/11O
        VQSMkFW/407TjesfGlJUkx+6a5Sv7RggCOU+hh+fuKdgMGrwNKrsFT0CgYEAyXIJ
        ym5hNJQ6h0MRwnNXi2hKViO4f2pvTNc2U0dcMZ7YHfMysTWvk2BQXVIjV7iEt2j4
        en7PkiGTz/ED+eqMqQQhEXmUdbKnMsugFJxSwi9lnIU78qjCW9HiX8u2oyAtKsQo
        SguvE426MjSGhZ1KgiXYWTGw0ryRHg0jGNqjD7cCgYEAmhtaUUXYOf+TIcW8Vx/+
        Qt9hpyC/BXe9Osj8kibKZ34XPSEL8R8vwIOHJJpDKCeEDu6vy5OKMNpsw5KJUZAK
        ZHPvSDApMx2n24fAa0lTzJjx40pPgQUqpBc8VNqTwxF4cXWNpyQMpk2o/frpzO+U
        XPfvUrT5z6S6umJqAFeSjG0CgYAAp5s6ijNMrXKnP+ON4zwUmukq8IDIATuNX2Gw
        0ZmOG7sOFd1DUC5a50Q7mWm9/j6ILhIoq8LW8b7+PQVLSaTdY8MLwH5oB4Wdl6XU
        i1GFigvlf1Vbi4reK4d10j6stw0Oh4at/u25vYsuYJdTVdiJJcBXQd8WQECkfVxw
        1z0SbwKBgEyZ+RjoWMB0NjzbuZRkrR2pr3oIaILw58sxksHW9yNRWaJGHobME/7x
        yqkB9xdD0haK5eZ8lm9miTigi1lRSHVLdUAxlP92itRyruFenSgEy+ohpuPfYbwj
        dpxnTDJVTPSSyILpnx9apgYsPMsPYI+/VGSFD317jXrQucx7cbv+
        -----END RSA PRIVATE KEY-----
        
        ```
        
5. cyberchef에 RSA-OAEP(SHA256) 으로 Decrypt를 진행한다.(key.pem 파일 내용을 개인키에 넣고 패스워드는 비워둔다.)
    
    [CyberChef](https://gchq.github.io/CyberChef/#recipe=From_Base64('A-Za-z0-9%2B/%3D',true,false)RSA_Decrypt('-----BEGIN%20RSA%20PRIVATE%20KEY-----%5CnMIIEowIBAAKCAQEAtiAq/vyEFT1I5uOBGJdPzZRgJ0eRVgKm9lpc4S7wQWSPY69x%5CnUJ%2ByMW0m/rQ3Qhgxv5e1BPlB4aYGMu9Py5jqDHrRKqeEn8hkDMg//PDl2oC8WHb8%5Cnu5UTR5%2B10mJ5HTL1uaWd1lBKpV810/W5U/yQiVdWZYjOTh13hLpxaxPOkp1Q2WUz%5CnRsdH7z0C49/LGx8M7wzHrIS1X7%2BoTPwvxYLn4wlfmzZQl4q1SVLM7ne6i7RI2Baj%5Cn8dYHeNivwMrCMnOfmEcngD2cK3tQBDQvdvV44Mm8YpNTwUxav5QTNZYYJMsB9Ofj%5CnxHWmtrp7bTRqxv9BmC4Gk401EZIyvP7Je9jBmwIDAQABAoIBACApPA59HwH1KYuE%5CnP0bNaY0/F1%2B4VqTeoQc928r0E/8oN939nEAFg10RDmLKBjwIs7hGnPO85HJpdAzI%5Cnj8m/Pg1oHsmufVAN/gT307zh%2BWUFeL0SffzODXKHdH8rXoHWfugCpAW1dgkP8Bx2%5Cn9vwqzIdEQgB6ERxgPbvVhLPI8qCXFL8J8Tw83Ld5NWTyCrTb50A/JmSqwSiXdeWx%5CnadyuPN39QrQryyoLWZQZQLntNqWHQWIZqQzayDLtbS7fvHwzU4TOBIs1i5zFoKyF%5Cn%2BmVGuQzXV5CUIzACEDYYlcI29O8qQpgmCHlZxkHc8Y/FCGpqXXY60Xbz6W68y7KT%5Cn9vb99skCgYEA53K2NTv7nGJgoWgOY9DjQ8NFsS3QIUSaHj/WG4izUc/3/k/luv3%2B%5CnLfpgt5vYJResQ1dLCn3NNZ5IstsxQyOmpKRDQVU1YDMIgfRHPPVJwpTNhPqc/11O%5CnVQSMkFW/407TjesfGlJUkx%2B6a5Sv7RggCOU%2Bhh%2BfuKdgMGrwNKrsFT0CgYEAyXIJ%5Cnym5hNJQ6h0MRwnNXi2hKViO4f2pvTNc2U0dcMZ7YHfMysTWvk2BQXVIjV7iEt2j4%5Cnen7PkiGTz/ED%2BeqMqQQhEXmUdbKnMsugFJxSwi9lnIU78qjCW9HiX8u2oyAtKsQo%5CnSguvE426MjSGhZ1KgiXYWTGw0ryRHg0jGNqjD7cCgYEAmhtaUUXYOf%2BTIcW8Vx/%2B%5CnQt9hpyC/BXe9Osj8kibKZ34XPSEL8R8vwIOHJJpDKCeEDu6vy5OKMNpsw5KJUZAK%5CnZHPvSDApMx2n24fAa0lTzJjx40pPgQUqpBc8VNqTwxF4cXWNpyQMpk2o/frpzO%2BU%5CnXPfvUrT5z6S6umJqAFeSjG0CgYAAp5s6ijNMrXKnP%2BON4zwUmukq8IDIATuNX2Gw%5Cn0ZmOG7sOFd1DUC5a50Q7mWm9/j6ILhIoq8LW8b7%2BPQVLSaTdY8MLwH5oB4Wdl6XU%5Cni1GFigvlf1Vbi4reK4d10j6stw0Oh4at/u25vYsuYJdTVdiJJcBXQd8WQECkfVxw%5Cn1z0SbwKBgEyZ%2BRjoWMB0NjzbuZRkrR2pr3oIaILw58sxksHW9yNRWaJGHobME/7x%5CnyqkB9xdD0haK5eZ8lm9miTigi1lRSHVLdUAxlP92itRyruFenSgEy%2BohpuPfYbwj%5CndpxnTDJVTPSSyILpnx9apgYsPMsPYI%2B/VGSFD317jXrQucx7cbv%2B%5Cn-----END%20RSA%20PRIVATE%20KEY-----','','RSA-OAEP','SHA-256')&input=TlNwWW1TQXhCdlRRTk5scGZ6SFhiUE96dkVmYkVrbnJSYnNYb3dUV3d1dU1rekU2RFZXdFc5VWlmOEIvRU9OMjBtclM5bEUyRngwU0hDbkYwL3pVV250MmxmWkR5TU96SnpTTWpCTWtsa2RzNXMwOTBvYnVjTDlaKzZwbXBSZEpCVXlrV3lHR2o4T0pmbVBNWTgrNDN5NkhqWDFWOHZQNEZJcGdScG9rbUhRK1AzTllhWTNyWVlhS2NGZWVtYU9ETlFFeVZBdm9lT3pBWEJJSHk4dXZWWS9HZHpSR0RMc1JNQUh3Y0JvK0Z3WEtuZHBPSlFsYy9uSlZNTEEvYk5KZk9aNjFqMkhTTVJQcm9KRDdLVXpLTlFzbVc2T0xTTXZjaHlDZng0Z3pBRllUZThIU1lFdm4yUEc4MWgxN0p1WElWRWZnNW40dC9YcFlkcmJvWlBqSnpRPT0&oeol=VT)
    
    ```python
    {"alg":"A256GCM","ext":true,"k":"8SEaae59bgNOQuq6rQrGwfaDwL9Oq81q6nf_Xd9SztM","key_ops":["encrypt","decrypt"],"kty":"oct"}
    ```
    
    **복호화된 방키 : 8SEaae59bgNOQuq6rQrGwfaDwL9Oq81q6nf_Xd9SztM**
    

### 메시지 복호화 방법

준비물 : 복호화된 방키, 메시지의 IV값, AES-256-GCM

1. 복호화 하고자 하는 메시지의 JSON에서 IV와 암호문을 식별한다.
    
    ```json
    {"_id":"DLeGauzSx2NyviQmc","rid":"6adc83d2a668235f28882cfc","e2eMentions":{"e2eUserMentions":[],"e2eChannelMentions":[]},"content":{"algorithm":"rc.v2.aes-sha2","kid":"61a76f88-caef-409d-9440-008ebaf009ad","iv":"zaGopI+J6xrX0rYo","ciphertext":"TRrZnYNzKscEiaRydCsbJq0wyJ0uRLDew4YVlA=="},"t":"e2e","ts":"2026-10-24T10:09:30.217000","u":{"_id":"xTjYthPqXQbhuxuok","username":"rocket01","name":"Test01"},"msg":"","_updatedAt":"2026-10-24T10:09:30.227000","mentions":[],"channels":[],"urls":[]}
    ```
    
    ```python
    iv: zaGopI+J6xrX0rYo
    ciphertext: TRrZnYNzKscEiaRydCsbJq0wyJ0uRLDew4YVlA==
    ```
    
2. ciphertext를 base64 decode를 하면 앞 12바이트는 실제 암호문이고 뒤 16바이트가 GCM 인증 태그이다.
    
    ```json
    base64_decode(TRrZnYNzKscEiaRydCsbJq0wyJ0uRLDew4YVlA==)
    => 4D1AD99D83732AC70489A472742B1B26AD30C89D2E44B0DEC3861594
    
    암호문 : 4D1AD99D83732AC70489A472
    GCM 인증 태그 : 742B1B26AD30C89D2E44B0DEC3861594
    ```
    
3. 복호화된 방키가 base64URL 방식이기 때문에 디코딩을 진행하여 키값으로 사용
    
    ```python
    import base64
    base64.urlsafe_b64decode('8SEaae59bgNOQuq6rQrGwfaDwL9Oq81q6nf_Xd9SztM=').hex()
    => f1211a69ee7d6e034e42eabaad0ac6c1f683c0bf4eabcd6aea77ff5ddf52ced3
    ```
    
4. 획득한 방키를 이용해서 AES-256-GCM 알고리즘으로 복호화를 진행
    
    [CyberChef](https://gchq.github.io/CyberChef/#recipe=AES_Decrypt(%7B'option':'Hex','string':'f1211a69ee7d6e034e42eabaad0ac6c1f683c0bf4eabcd6aea77ff5ddf52ced3'%7D,%7B'option':'Base64','string':'zaGopI%2BJ6xrX0rYo'%7D,16,'GCM','Hex','Raw',%7B'option':'Hex','string':'742B1B26AD30C89D2E44B0DEC3861594'%7D,%7B'option':'Hex','string':''%7D,'Off')&input=NEQxQUQ5OUQ4MzczMkFDNzA0ODlBNDcy)
    

### 첨부 파일 복호화

준비물 : 암호화된 첨부파일, 복호화된 방키, 메시지의 IV값, AES-256-GCM

1. 복호화 하고자 하는 메시지의 JSON에서 IV와 암호문을 식별한다.
    
    ```json
    {"rid":"6adc83d2a668235f28882cfc","ts":"2026-10-24T10:11:09.573000","content":{"algorithm":"rc.v2.aes-sha2","kid":"61a76f88-caef-409d-9440-008ebaf009ad","iv":"VIYLOVvGAEb3Yfb5","ciphertext":"q/alPBqUtGceEku3ZcpyjPgn/x4Out4mYIG6vm6aP2iydfwVMhmgdGVfX/q0M72NvUbiIOhCTXxW4hvjux9csNgrD7Z/YLXLFuuARAlDLYfThuxeoT5/rbtCp+y3TYZSjviX5qjtXtoRfJlYBGQo/hJj8yzH47BB4irs6xjwG+BbrMSnV6M6VljeZVwcxkiaAtaF+SgThZ4bipAckl0rfuWPGe91xOnFjGbjaWnYdPJhuNP8PUmm1/r52jWJXjDHT9jqvrjBLLkZGFU09SuDPh2ptpRItB0UtVgNzZ6k5+yxDWrllEb7Cbfti/HNgAsKv6FMmUfRMmy9UAN7e3QyAKyPGisDwIzp0lTwMt6synq0NPpiG4Ghsz1ooTRzolGhwJVnziJiYX0NrgMfg18TjmrFELY8Yp4rNi4avaTNPROy6ORo0RXgpgh/72ApYT0vtxmNnh7jpeyqbozbAr3lzfWciJySmwTNWLBOmV9XV7d4sx98NOpNqa1gaQ/kYjo+g24XWLn+rUtKpiqG66e5XzJSs68xkmCySI8nLPn82CY6RL+CbH7SFxNTk+kONKIYvCORTftXElAC8HbVstWHx5r06BlSxpPXO9yaC+fa2P1/QYhovY/NbvuiaB0FRFFew5JMYRT3O80O9ERlWXp8jKNHFnc0ZF9DhlSFf0dmdpyxXlnHqNefgwtT8BH5DTaJSTQy8Bwj4DzKpALa4Podwar/VEUFBpibBxICpBNsn3NIsDTYtbLcIxOn06ygvrO8e9eufkeQXKOAQIC/KakBBB/0hQlZ3nUtP0mn7fc0G+ZDWCwsXTq9DM7fEebMvml+uStw056fWrtIcyU7QD4n9ECMNVcXzr03Xg3W/fAZ1m9RnhFemnzwsHpSK7LcKvVbAjmbvUjioFACnQuPiRYSx4l7/IkTNlRSyW6TbQqfoPfpguUDbac4ojbX5h2Y6OxtZlaARHuDru2MubyoNUopQvec8UkFCFWnm0Wei5Zc/6XYQ0GYdmgXmECKtQm3QQ10R4nRL8ty3Zps7MG0XbAGNMmyGi9dJpi8XbrcE7MZyRvUboQRlnqS5J4gkc/IQ3YGAq7dZHL52gzgW//qc8xqPdFgJmQPEXd65jy4QprqPT2NiGiZvDYLMzNY6/EvyFn2cP9QIL1x5nd2Qao7xwmws7/Vagf0lI+UtnP/Q8MKNi3qjAkSp03LTZYmGbOUOFWbKiymW8jP/zH7BLA8WJpUX3pifuSs8XT2QLO9znv3tsWIVBR9dku0//Ore2I+380GkeyCmIw5mhlUUivm4H6MOJHI/RM4wfu3hgSXRIvkidYGRrK+/6g9r4iFtxRrZOk66ty2k/GG7OAmR13AT9D3rqXacRD/vEMsl/1QUoa4AgVCuJ5zxXho"},"t":"e2e","msg":"","groupable":false,"file":{"_id":"6adc843ca668235f28882d06","name":"38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","type":"application/octet-stream","size":366293,"format":"","typeGroup":"application"},"files":[{"_id":"6adc843ca668235f28882d06","name":"38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","type":"application/octet-stream","size":366293,"format":"","typeGroup":"application"}],"attachments":[{"title":"38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","title_link":"/file-upload/6adc843ca668235f28882d06/38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","title_link_download":true,"type":"file","format":"file","size":366293,"fileId":"6adc843ca668235f28882d06"}],"u":{"_id":"xTjYthPqXQbhuxuok","username":"rocket01","name":"Test01"},"_id":"52rZTGdYpvTtq8o47","_updatedAt":"2026-10-24T10:11:09.587000","mentions":[],"channels":[],"urls":[]}
    ```
    
    ```python
    iv: VIYLOVvGAEb3Yfb5
    ciphertext: q/alPBqUtGceEku3ZcpyjPgn/x4Out4mYIG6vm6aP2iydfwVMhmgdGVfX/q0M72NvUbiIOhCTXxW4hvjux9csNgrD7Z/YLXLFuuARAlDLYfThuxeoT5/rbtCp+y3TYZSjviX5qjtXtoRfJlYBGQo/hJj8yzH47BB4irs6xjwG+BbrMSnV6M6VljeZVwcxkiaAtaF+SgThZ4bipAckl0rfuWPGe91xOnFjGbjaWnYdPJhuNP8PUmm1/r52jWJXjDHT9jqvrjBLLkZGFU09SuDPh2ptpRItB0UtVgNzZ6k5+yxDWrllEb7Cbfti/HNgAsKv6FMmUfRMmy9UAN7e3QyAKyPGisDwIzp0lTwMt6synq0NPpiG4Ghsz1ooTRzolGhwJVnziJiYX0NrgMfg18TjmrFELY8Yp4rNi4avaTNPROy6ORo0RXgpgh/72ApYT0vtxmNnh7jpeyqbozbAr3lzfWciJySmwTNWLBOmV9XV7d4sx98NOpNqa1gaQ/kYjo+g24XWLn+rUtKpiqG66e5XzJSs68xkmCySI8nLPn82CY6RL+CbH7SFxNTk+kONKIYvCORTftXElAC8HbVstWHx5r06BlSxpPXO9yaC+fa2P1/QYhovY/NbvuiaB0FRFFew5JMYRT3O80O9ERlWXp8jKNHFnc0ZF9DhlSFf0dmdpyxXlnHqNefgwtT8BH5DTaJSTQy8Bwj4DzKpALa4Podwar/VEUFBpibBxICpBNsn3NIsDTYtbLcIxOn06ygvrO8e9eufkeQXKOAQIC/KakBBB/0hQlZ3nUtP0mn7fc0G+ZDWCwsXTq9DM7fEebMvml+uStw056fWrtIcyU7QD4n9ECMNVcXzr03Xg3W/fAZ1m9RnhFemnzwsHpSK7LcKvVbAjmbvUjioFACnQuPiRYSx4l7/IkTNlRSyW6TbQqfoPfpguUDbac4ojbX5h2Y6OxtZlaARHuDru2MubyoNUopQvec8UkFCFWnm0Wei5Zc/6XYQ0GYdmgXmECKtQm3QQ10R4nRL8ty3Zps7MG0XbAGNMmyGi9dJpi8XbrcE7MZyRvUboQRlnqS5J4gkc/IQ3YGAq7dZHL52gzgW//qc8xqPdFgJmQPEXd65jy4QprqPT2NiGiZvDYLMzNY6/EvyFn2cP9QIL1x5nd2Qao7xwmws7/Vagf0lI+UtnP/Q8MKNi3qjAkSp03LTZYmGbOUOFWbKiymW8jP/zH7BLA8WJpUX3pifuSs8XT2QLO9znv3tsWIVBR9dku0//Ore2I+380GkeyCmIw5mhlUUivm4H6MOJHI/RM4wfu3hgSXRIvkidYGRrK+/6g9r4iFtxRrZOk66ty2k/GG7OAmR13AT9D3rqXacRD/vEMsl/1QUoa4AgVCuJ5zxXho
    ```
    
2. ciphertext를 base64 decode를 하면 앞 12바이트는 실제 암호문이고 뒤 16바이트가 GCM 인증 태그이다.
    
    ```json
    import base64
    base64.b64decode('q/alPBqUtGceEku3ZcpyjPgn/x4Out4mYIG6vm6aP2iydfwVMhmgdGVfX/q0M72NvUbiIOhCTXxW4hvjux9csNgrD7Z/YLXLFuuARAlDLYfThuxeoT5/rbtCp+y3TYZSjviX5qjtXtoRfJlYBGQo/hJj8yzH47BB4irs6xjwG+BbrMSnV6M6VljeZVwcxkiaAtaF+SgThZ4bipAckl0rfuWPGe91xOnFjGbjaWnYdPJhuNP8PUmm1/r52jWJXjDHT9jqvrjBLLkZGFU09SuDPh2ptpRItB0UtVgNzZ6k5+yxDWrllEb7Cbfti/HNgAsKv6FMmUfRMmy9UAN7e3QyAKyPGisDwIzp0lTwMt6synq0NPpiG4Ghsz1ooTRzolGhwJVnziJiYX0NrgMfg18TjmrFELY8Yp4rNi4avaTNPROy6ORo0RXgpgh/72ApYT0vtxmNnh7jpeyqbozbAr3lzfWciJySmwTNWLBOmV9XV7d4sx98NOpNqa1gaQ/kYjo+g24XWLn+rUtKpiqG66e5XzJSs68xkmCySI8nLPn82CY6RL+CbH7SFxNTk+kONKIYvCORTftXElAC8HbVstWHx5r06BlSxpPXO9yaC+fa2P1/QYhovY/NbvuiaB0FRFFew5JMYRT3O80O9ERlWXp8jKNHFnc0ZF9DhlSFf0dmdpyxXlnHqNefgwtT8BH5DTaJSTQy8Bwj4DzKpALa4Podwar/VEUFBpibBxICpBNsn3NIsDTYtbLcIxOn06ygvrO8e9eufkeQXKOAQIC/KakBBB/0hQlZ3nUtP0mn7fc0G+ZDWCwsXTq9DM7fEebMvml+uStw056fWrtIcyU7QD4n9ECMNVcXzr03Xg3W/fAZ1m9RnhFemnzwsHpSK7LcKvVbAjmbvUjioFACnQuPiRYSx4l7/IkTNlRSyW6TbQqfoPfpguUDbac4ojbX5h2Y6OxtZlaARHuDru2MubyoNUopQvec8UkFCFWnm0Wei5Zc/6XYQ0GYdmgXmECKtQm3QQ10R4nRL8ty3Zps7MG0XbAGNMmyGi9dJpi8XbrcE7MZyRvUboQRlnqS5J4gkc/IQ3YGAq7dZHL52gzgW//qc8xqPdFgJmQPEXd65jy4QprqPT2NiGiZvDYLMzNY6/EvyFn2cP9QIL1x5nd2Qao7xwmws7/Vagf0lI+UtnP/Q8MKNi3qjAkSp03LTZYmGbOUOFWbKiymW8jP/zH7BLA8WJpUX3pifuSs8XT2QLO9znv3tsWIVBR9dku0//Ore2I+380GkeyCmIw5mhlUUivm4H6MOJHI/RM4wfu3hgSXRIvkidYGRrK+/6g9r4iFtxRrZOk66ty2k/GG7OAmR13AT9D3rqXacRD/vEMsl/1QUoa4AgVCuJ5zxXho').hex()
    => 'abf6a53c1a94b4671e124bb765ca728cf827ff1e0ebade266081babe6e9a3f68b275fc153219a074655f5ffab433bd8dbd46e220e8424d7c56e21be3bb1f5cb0d82b0fb67f60b5cb16eb804409432d87d386ec5ea13e7fadbb42a7ecb74d86528ef897e6a8ed5eda117c9958046428fe1263f32cc7e3b041e22aeceb18f01be05bacc4a757a33a5658de655c1cc6489a02d685f92813859e1b8a901c925d2b7ee58f19ef75c4e9c58c66e36969d874f261b8d3fc3d49a6d7faf9da35895e30c74fd8eabeb8c12cb919185534f52b833e1da9b69448b41d14b5580dcd9ea4e7ecb10d6ae59446fb09b7ed8bf1cd800b0abfa14c9947d1326cbd50037b7b743200ac8f1a2b03c08ce9d254f032deacca7ab434fa621b81a1b33d68a13473a251a1c09567ce2262617d0dae031f835f138e6ac510b63c629e2b362e1abda4cd3d13b2e8e468d115e0a6087fef6029613d2fb7198d9e1ee3a5ecaa6e8cdb02bde5cdf59c889c929b04cd58b04e995f5757b778b31f7c34ea4da9ad60690fe4623a3e836e1758b9fead4b4aa62a86eba7b95f3252b3af319260b2488f272cf9fcd8263a44bf826c7ed217135393e90e34a218bc23914dfb57125002f076d5b2d587c79af4e81952c693d73bdc9a0be7dad8fd7f418868bd8fcd6efba2681d0544515ec3924c6114f73bcd0ef44465597a7c8ca347167734645f438654857f4766769cb15e59c7a8d79f830b53f011f90d3689493432f01c23e03ccaa402dae0fa1dc1aaff54450506989b071202a4136c9f7348b034d8b5b2dc2313a7d3aca0beb3bc7bd7ae7e47905ca3804080bf29a901041ff4850959de752d3f49a7edf7341be643582c2c5d3abd0ccedf11e6ccbe697eb92b70d39e9f5abb4873253b403e27f4408c355717cebd375e0dd6fdf019d66f519e115e9a7cf0b07a522bb2dc2af55b02399bbd48e2a050029d0b8f891612c7897bfc8913365452c96e936d0a9fa0f7e982e5036da738a236d7e61d98e8ec6d665680447b83aeed8cb9bca8354a2942f79cf149050855a79b459e8b965cffa5d843419876681798408ab509b7410d744789d12fcb72dd9a6cecc1b45db00634c9b21a2f5d2698bc5dbadc13b319c91bd46e8411967a92e49e2091cfc843760602aedd6472f9da0ce05bffea73cc6a3dd16026640f11777ae63cb8429aea3d3d8d886899bc360b333358ebf12fc859f670ff5020bd71e6777641aa3bc709b0b3bfd56a07f4948f94b673ff43c30a362dea8c0912a74dcb4d962619b39438559b2a2ca65bc8cfff31fb04b03c589a545f7a627ee4acf174f640b3bdce7bf7b6c58854147d764bb4fff3ab7b623edfcd0691ec82988c399a1954522be6e07e8c3891c8fd1338c1fbb7860497448be489d60646b2beffa83daf8885b7146b64e93aeadcb693f186ece026475dc04fd0f7aea5da7110ffbc432c97fd505286b8020542b89e73c57868'
    
    암호문 : 1031바이트 생략.
    GCM 인증 태그 : 2c97fd505286b8020542b89e73c57868
    ```
    
3. 복호화된 방키가 base64URL 방식이기 때문에 디코딩을 진행하여 키값으로 사용
    
    ```python
    import base64
    base64.urlsafe_b64decode('8SEaae59bgNOQuq6rQrGwfaDwL9Oq81q6nf_Xd9SztM=').hex()
    => f1211a69ee7d6e034e42eabaad0ac6c1f683c0bf4eabcd6aea77ff5ddf52ced3
    ```
    
4. 획득한 방키를 이용해서 AES-256-GCM 알고리즘으로 복호화를 진행
    
    [CyberChef](https://gchq.github.io/CyberChef/#recipe=AES_Decrypt(%7B'option':'Hex','string':'f1211a69ee7d6e034e42eabaad0ac6c1f683c0bf4eabcd6aea77ff5ddf52ced3'%7D,%7B'option':'Base64','string':'VIYLOVvGAEb3Yfb5'%7D,16,'GCM','Hex','Raw',%7B'option':'Hex','string':'2C97FD505286B8020542B89E73C57868'%7D,%7B'option':'Hex','string':''%7D,'Off')&input=YWJmNmE1M2MxYTk0YjQ2NzFlMTI0YmI3NjVjYTcyOGNmODI3ZmYxZTBlYmFkZTI2NjA4MWJhYmU2ZTlhM2Y2OGIyNzVmYzE1MzIxOWEwNzQ2NTVmNWZmYWI0MzNiZDhkYmQ0NmUyMjBlODQyNGQ3YzU2ZTIxYmUzYmIxZjVjYjBkODJiMGZiNjdmNjBiNWNiMTZlYjgwNDQwOTQzMmQ4N2QzODZlYzVlYTEzZTdmYWRiYjQyYTdlY2I3NGQ4NjUyOGVmODk3ZTZhOGVkNWVkYTExN2M5OTU4MDQ2NDI4ZmUxMjYzZjMyY2M3ZTNiMDQxZTIyYWVjZWIxOGYwMWJlMDViYWNjNGE3NTdhMzNhNTY1OGRlNjU1YzFjYzY0ODlhMDJkNjg1ZjkyODEzODU5ZTFiOGE5MDFjOTI1ZDJiN2VlNThmMTllZjc1YzRlOWM1OGM2NmUzNjk2OWQ4NzRmMjYxYjhkM2ZjM2Q0OWE2ZDdmYWY5ZGEzNTg5NWUzMGM3NGZkOGVhYmViOGMxMmNiOTE5MTg1NTM0ZjUyYjgzM2UxZGE5YjY5NDQ4YjQxZDE0YjU1ODBkY2Q5ZWE0ZTdlY2IxMGQ2YWU1OTQ0NmZiMDliN2VkOGJmMWNkODAwYjBhYmZhMTRjOTk0N2QxMzI2Y2JkNTAwMzdiN2I3NDMyMDBhYzhmMWEyYjAzYzA4Y2U5ZDI1NGYwMzJkZWFjY2E3YWI0MzRmYTYyMWI4MWExYjMzZDY4YTEzNDczYTI1MWExYzA5NTY3Y2UyMjYyNjE3ZDBkYWUwMzFmODM1ZjEzOGU2YWM1MTBiNjNjNjI5ZTJiMzYyZTFhYmRhNGNkM2QxM2IyZThlNDY4ZDExNWUwYTYwODdmZWY2MDI5NjEzZDJmYjcxOThkOWUxZWUzYTVlY2FhNmU4Y2RiMDJiZGU1Y2RmNTljODg5YzkyOWIwNGNkNThiMDRlOTk1ZjU3NTdiNzc4YjMxZjdjMzRlYTRkYTlhZDYwNjkwZmU0NjIzYTNlODM2ZTE3NThiOWZlYWQ0YjRhYTYyYTg2ZWJhN2I5NWYzMjUyYjNhZjMxOTI2MGIyNDg4ZjI3MmNmOWZjZDgyNjNhNDRiZjgyNmM3ZWQyMTcxMzUzOTNlOTBlMzRhMjE4YmMyMzkxNGRmYjU3MTI1MDAyZjA3NmQ1YjJkNTg3Yzc5YWY0ZTgxOTUyYzY5M2Q3M2JkYzlhMGJlN2RhZDhmZDdmNDE4ODY4YmQ4ZmNkNmVmYmEyNjgxZDA1NDQ1MTVlYzM5MjRjNjExNGY3M2JjZDBlZjQ0NDY1NTk3YTdjOGNhMzQ3MTY3NzM0NjQ1ZjQzODY1NDg1N2Y0NzY2NzY5Y2IxNWU1OWM3YThkNzlmODMwYjUzZjAxMWY5MGQzNjg5NDkzNDMyZjAxYzIzZTAzY2NhYTQwMmRhZTBmYTFkYzFhYWZmNTQ0NTA1MDY5ODliMDcxMjAyYTQxMzZjOWY3MzQ4YjAzNGQ4YjViMmRjMjMxM2E3ZDNhY2EwYmViM2JjN2JkN2FlN2U0NzkwNWNhMzgwNDA4MGJmMjlhOTAxMDQxZmY0ODUwOTU5ZGU3NTJkM2Y0OWE3ZWRmNzM0MWJlNjQzNTgyYzJjNWQzYWJkMGNjZWRmMTFlNmNjYmU2OTdlYjkyYjcwZDM5ZTlmNWFiYjQ4NzMyNTNiNDAzZTI3ZjQ0MDhjMzU1NzE3Y2ViZDM3NWUwZGQ2ZmRmMDE5ZDY2ZjUxOWUxMTVlOWE3Y2YwYjA3YTUyMmJiMmRjMmFmNTViMDIzOTliYmQ0OGUyYTA1MDAyOWQwYjhmODkxNjEyYzc4OTdiZmM4OTEzMzY1NDUyYzk2ZTkzNmQwYTlmYTBmN2U5ODJlNTAzNmRhNzM4YTIzNmQ3ZTYxZDk4ZThlYzZkNjY1NjgwNDQ3YjgzYWVlZDhjYjliY2E4MzU0YTI5NDJmNzljZjE0OTA1MDg1NWE3OWI0NTllOGI5NjVjZmZhNWQ4NDM0MTk4NzY2ODE3OTg0MDhhYjUwOWI3NDEwZDc0NDc4OWQxMmZjYjcyZGQ5YTZjZWNjMWI0NWRiMDA2MzRjOWIyMWEyZjVkMjY5OGJjNWRiYWRjMTNiMzE5YzkxYmQ0NmU4NDExOTY3YTkyZTQ5ZTIwOTFjZmM4NDM3NjA2MDJhZWRkNjQ3MmY5ZGEwY2UwNWJmZmVhNzNjYzZhM2RkMTYwMjY2NDBmMTE3NzdhZTYzY2I4NDI5YWVhM2QzZDhkODg2ODk5YmMzNjBiMzMzMzU4ZWJmMTJmYzg1OWY2NzBmZjUwMjBiZDcxZTY3Nzc2NDFhYTNiYzcwOWIwYjNiZmQ1NmEwN2Y0OTQ4Zjk0YjY3M2ZmNDNjMzBhMzYyZGVhOGMwOTEyYTc0ZGNiNGQ5NjI2MTliMzk0Mzg1NTliMmEyY2E2NWJjOGNmZmYzMWZiMDRiMDNjNTg5YTU0NWY3YTYyN2VlNGFjZjE3NGY2NDBiM2JkY2U3YmY3YjZjNTg4NTQxNDdkNzY0YmI0ZmZmM2FiN2I2MjNlZGZjZDA2OTFlYzgyOTg4YzM5OWExOTU0NTIyYmU2ZTA3ZThjMzg5MWM4ZmQxMzM4YzFmYmI3ODYwNDk3NDQ4YmU0ODlkNjA2NDZiMmJlZmZhODNkYWY4ODg1YjcxNDZiNjRlOTNhZWFkY2I2OTNmMTg2ZWNlMDI2NDc1ZGMwNGZkMGY3YWVhNWRhNzExMGZmYmM0Mw)
    
5. 식별한 첨부파일의 암호화 키, IV 값을 이용해서 암호화된 첨부파일을 복호화 진행
    
    ```python
    {"attachments":[{"title":"Clipboard - 2026년 10월 24일 19:11.png","type":"file","title_link":"/file-upload/6adc843ca668235f28882d06/38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","title_link_download":true,"encryption":{"key":{"alg":"A256CTR","ext":true,"k":"-S6SPKVRpTDqaIPUM64cuzfQvOoer4lcq3nkhWkJEaY","key_ops":["encrypt","decrypt"],"kty":"oct"},"iv":"LmFLAtH8d4+o5AZ0cEDkJQ=="},"hashes":{"sha256":"0c06b6ef8a0ff2092256001897073db53df1141fb373618fe6a911a5dc317879"},"fileId":"6adc843ca668235f28882d06","image_url":"/file-upload/6adc843ca668235f28882d06/38a6d2c8a33b38e65303ead890f37c09a9f70ce69e55d0fe69292bf1d1a714e4","image_type":"image/png","image_size":366293,"image_dimensions":{"height":373,"width":560}}],"files":[{"_id":"6adc843ca668235f28882d06","name":"Clipboard - 2026년 10월 24일 19:11.png","type":"image/png","size":366293,"format":"PNG"}],"file":{"_id":"6adc843ca668235f28882d06","name":"Clipboard - 2026년 10월 24일 19:11.png","type":"image/png","size":366293,"format":"PNG"},"msg":""}
    ```
    
    ```python
    KEY : -S6SPKVRpTDqaIPUM64cuzfQvOoer4lcq3nkhWkJEaY=
    IV : LmFLAtH8d4+o5AZ0cEDkJQ==
    ```
    
6. 5번에서 확인한 KEY 값은 base64URL 방식이기 때문에 디코딩을 진행하여 키값으로 사용
    
    ```python
    import base64
    base64.urlsafe_b64decode('-S6SPKVRpTDqaIPUM64cuzfQvOoer4lcq3nkhWkJEaY=').hex()
    => f92e923ca551a530ea6883d433ae1cbb37d0bcea1eaf895cab79e485690911a6
    ```
    
7. AES 256 CTR로 복호화 진행
    
    [5_attach_encrypted_6adc843ca668235f28882d06.bin](5_attach_encrypted_6adc843ca668235f28882d06.bin)
    
    [CyberChef](https://gchq.github.io/CyberChef/#recipe=AES_Decrypt(%7B'option':'Hex','string':'f92e923ca551a530ea6883d433ae1cbb37d0bcea1eaf895cab79e485690911a6'%7D,%7B'option':'Base64','string':'LmFLAtH8d4%2Bo5AZ0cEDkJQ%3D%3D'%7D,16,'CTR','Raw','Raw',%7B'option':'Hex','string':''%7D,%7B'option':'Hex','string':''%7D,'Off')&oeol=FF)
    
    ![download.png](download.png)