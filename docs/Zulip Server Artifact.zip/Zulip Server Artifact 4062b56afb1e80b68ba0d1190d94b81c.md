# Zulip Server Artifact

Status: Completed (Pending Additions)

## Zulip Server 란?

Zulip은 오픈소스 팀 채팅 서버이다. standalone 설치본은 한 리눅스 호스트에서 Django 애플리케이션과 Tornado 이벤트 서버, uWSGI, nginx, PostgreSQL, RabbitMQ, Redis, memcached를 supervisor로 함께 실행한다. 애플리케이션 코드는 /home/zulip/deployments/current 에 있고, current는 타임스탬프 디렉터리를 가리키는 심볼릭 링크다. 조직 데이터인 메시지와 사용자, 스트림은 PostgreSQL에, 업로드 파일은 settings.py의 LOCAL_UPLOADS_DIR가 가리키는 로컬 디렉터리에 저장된다.

메신저 클라이언트와 서버 사이에 종단간 암호화가 없으므로, 서버 디스크에는 메시지 본문이 평문으로 남는다. 서버 디스크 한 장이면 조직 전체의 대화를 재구성할 수 있다.

### **주요 특징**

- **자체 호스팅 (Self-hosting) :** 조직이 직접 운영하는 서버라 모든 데이터가 그 호스트의 디스크에 남는다.
- **스트림 기반 대화 (Streams) :** 주제별 스트림과 다이렉트 메시지가 zerver_message와 zerver_recipient로 저장된다.
- **PostgreSQL 저장 (PostgreSQL)** : 메시지와 사용자, 조직이 관계형 DB Heap 파일에 평문으로 쌓인다.
- **로컬 업로드 (Local uploads)** : 첨부 파일이 /home/zulip/uploads 아래 원본 그대로 저장된다.
- **종단간 암호화 없음 (No E2EE)** : 전송 구간만 암호화라 디스크의 본문은 평문이다.
- **통합 설치 (Standalone deb)** : DB와 큐, 캐시까지 한 호스트에 올라가 디스크 한 장에 전부 들어간다.

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Zulip Server 12.3 |
| 설치 방식 | standalone deb 설치 (zulip.conf puppet_classes가 zulip::profile::standalone, deploy_type production) |
| OS / 버전 | Ubuntu 26.04.1 LTS (Resolute Raccoon), VMware VM, hostname user1-VMware-Virtual-Platform, TZ Asia/Seoul |
| 데이터베이스 | PostgreSQL 18 (/var/lib/postgresql/18/main, DB OID 16385) |
| 샘플 수집 방법 | 디스크를 FTK Imager(ADI) 8.2.0.59로 EWF/E01 수집 |
| 계정 | 테스트 조직 zulip test. 사람 사용자 2명(zulip1, zulip2)과 시스템 봇 7개 |

## 아티팩트 경로 및 설명(Zulip **Server**)

서버에서 볼 경로는 아래와 같다. 메시지와 사용자, 조직 같은 데이터의 원본은 PostgreSQL에 모이고, 업로드된 파일은 디스크에 원본 그대로 저장되며, 설치 방식과 접속 정보, 서버 시크릿은 /etc/zulip의 설정 파일에, 버전과 기동, 접속 흔적은 /var/log/zulip의 로그에 남는다.

| 파일 경로 | 설명 |
| --- | --- |
| /var/lib/postgresql/18/main | PostgreSQL이 실제로 쓰는 라이브 클러스터 파일(heap)이다. pg_dump가 없어도 이 파일에서 직접 메시지 평문을 꺼낼 수 있다. |
| /home/zulip/uploads | 로컬 업로드 저장소로 files 아래에 첨부 원본과 tus 메타데이터, 썸네일이, avatars 아래에 사용자 아바타가 들어 있고, 경로 꼬리가 DB의 path_id와 일치한다 |
| /etc/zulip/zulip-secrets.conf | 서버 시크릿을 담은 ini 파일. secret_key, rabbitmq_password, shared_secret 등 9종이 평문으로 있어 세션과 내부 서비스 인증의 단서가 된다 |
| /etc/zulip/settings.py, zulip.conf | 서버 설정. 설치 방식과 EXTERNAL_HOST, 업로드 경로(LOCAL_UPLOADS_DIR), 인증 백엔드, 데이터베이스와 PostgreSQL 버전을 확인할 수 있다. |
| /var/log/zulip | 서버 활동 로그. server.log와 django.log, events.log 등에 요청 시각과 경로, 계정, 클라이언트, IP가 남아 활동 시각을 알 수 있다. |
| /home/zulip/deployments/current | 현재 배포를 가리키는 심볼릭 링크로 타임스탬프 디렉터리 아래 애플리케이션 코드와 version.py가 있어 Zulip 버전(12.3)을 확인할 수 있다. |

### PostgreSQL Heap(/var/lib/postgresql/18/main/base/16385) 데이터베이스 분석

Zulip DB는 base/16385 아래에 테이블마다 relfilenode 숫자를 이름으로 한 힙 파일로 저장된다. 덤프 파일이 없어, 카탈로그 pg_class와 pg_attribute를 고정 헤더 오프셋으로 디코드해 테이블 이름과 relfilenode, 컬럼 레이아웃을 얻을 수 있다. pd_dump 명령어를 통해 SQL 내용을 쉽게 획득할 수 있으나 라이브 상태에서 수집해야하는 단점이 있다.

pg_dump 명령어 : `sudo -u postgres pg_dump zulip > zulip.sql`(zulip이 DB 명)

pg_dump 같은 논리 백업이 없어도, PostgreSQL이 실제로 쓰는 클러스터 파일(heap)에서 바이트를 직접 읽어 같은 메시지를 복원할 수 있다. PostgreSQL DB를 분석하는 방법으로는 앞에서 이야기한 것 처럼 방법은 여러가지가 존재한다.

1. PostgreSQL을 Docker 또는 서버로 올려서 수집한 PostgreSQL 폴더를 이식시켜서 로드하는 방법
2. 수집한 PostgreSQL 폴더를 분석 도구에 넣어서 분석하는 방법

1번 방식이 일반적인 분석 방법이고, 2번은 현재 PostgreSQL 폴더를 input으로 받아서 분석해주는 도구가 없다. 그래서 임시로 사용할 PostgreSQL DB 분석 도구를 개발하였다. 해당 도구에 데이터를 넣어보면 아래와 같다.

![image.png](image.png)

위와 같이 무수히 많은 테이블이 존재하고 zerver_message 테이블에 다양한 데이터가 저장되어 있는데, 실제로 content 칼럼을 확인해 보면 각 행마다 입력한 메시지를 확인해 볼 수 있다. 아래는 중요 테이블 관련 표이다.

| **테이블** | **핵심 컬럼** | **복원 수** | **샘플 값** |
| --- | --- | --- | --- |
| zerver_message | id, date_sent, sender_id, recipient_id, subject, content | 메시지 **37** | 본문 평문 복원, 제목 평문 |
| zerver_userprofile | id, delivery_email, full_name, role, password, api_key | 사용자 **9** | 해시 argon2, API 키 32자 |
| zerver_realm | id, name, string_id, org_type | 조직 **2** | zulip test (`org_type` 10) |
| zerver_stream | id, name, invite_only, description | 스트림 **5** | 공개 3, 비공개 1 포함 |
| zerver_recipient | id, type | **7** | type 2(스트림) 5, type 3(DM 그룹) 2 |
| zerver_subscription | user_profile_id, recipient_id, active | 구독 **14** | 전부 active |
| zerver_attachment | id, owner_id, file_name, path_id, size | 첨부 **4** | 디스크 원본과 매핑 |

사용자 비밀번호는 시스템 봇 7개가 사용 불가 표시(느낌표 접두)고, 사람 사용자 2명은 argon2 해시였다.

### /home/zulip/uploads 분석

settings.py의 LOCAL_UPLOADS_DIR가 /home/zulip/uploads라 첨부 원본이 디스크에 그대로 있다. files 아래 경로는 realm_id와 랜덤 토큰, 원본 파일명으로 이뤄지고, 이 경로 꼬리가 zerver_attachment의 path_id와 일치한다.

| path_id (uploads/files 기준) | 크기 | DB 매핑 |
| --- | --- | --- |
| 2/93/.../zulip_Meeting_Notes.pdf | 2443 | attachment id 1, owner 8 |
| 2/1b/.../image.png | 295306 | attachment id 2, owner 9 |
| 2/7f/.../image.png | 260175 | attachment id 3, owner 9 |
| 2/90/.../zulip_Meeting_Notes2.pdf | 2443 | attachment id 4, owner 8 |

DB의 첨부 4건이 모두 디스크 파일과 매핑됐으며, PDF 2개는 sha256이 같아 같은 파일을 2번 올린것이다. 파일마다 tus 업로드 메타데이터 .info 사이드카가 있고, 이미지에는 840x560 WebP 썸네일이 따로 생성돼 있다. 아바타는 avatars 아래 realm별로 원본과 medium 크기가 PNG로 저장된다.

### /etc/zulip 분석

zulip-secrets.conf는 ini 형식으로 시크릿 9종을 저장하고 있다. 아래의 표는 9종류의 데이터이다.

| **키** | **길이** | **용도(문서 기준)** |
| --- | --- | --- |
| secret_key | 50 | Django 세션과 서명 |
| avatar_salt | 64 | 아바타 경로 해시 솔트 |
| rabbitmq_password | 64 | RabbitMQ 인증 |
| shared_secret | 64 | 내부 서비스 인증 |
| camo_key | 64 | 이미지 프록시 서명 |
| memcached_password | 64 | memcached 인증 |
| redis_password | 64 | Redis 인증 |
| zulip_org_key | 64 | 푸시 알림 서비스 등록 |
| zulip_org_id | 36 | 조직 식별자 |

settings.py에서 EXTERNAL_HOST가 zulip.lab, ZULIP_ADMINISTRATOR가 관리자 이메일, LOCAL_UPLOADS_DIR가 /home/zulip/uploads인것도 확인해 볼 수 있는데, 이처럼 py에 작성된 데이터를 기반으로 연결된 정보를 획득할 수 있다.

### /var/log/zulip 분석

/var/log/zulip 아래에 server.log, django.log, events.log, workers.log, tornado.log, install.log 등 서비스별 로그가 텍스트로 남는다. 각 로그의 접두 시각은 모두 2026-10-25 07시에서 09시 구간에 모여 DB의 활동 시각과 맞는다.

install.log에는 Zulip 12.3 설치 과정과 배포 경로 /home/zulip/deployments/2026-10-25-16-45-27 가 남아 버전과 배포 시점을 확인할 수 있다. server.log와 django.log의 요청 라인에는 시각, 클라이언트 IP, 요청 경로, 계정, User-Agent가 남는다. 가입(/accounts/register/, /realm/register/)과 로그인(/accounts/login/subdomain/...), presence 갱신 요청이 보인다.

```
2026-10-25 08:03:47 INFO 192.168.*.* POST 200 /realm/register/     (un***@root via Mozilla)
2026-10-25 08:06:48 INFO 192.168.*.* POST 302 /accounts/register/  (un***@root via Mozilla)
2026-10-25 08:06:48 INFO 192.168.*.* GET  302 /accounts/login/subdomain/******** (8***@root via Mozilla)
```

위와 같은 요청 라인으로 가입과 로그인 흐름의 시각과 출처 IP를 복원할 수 있다.