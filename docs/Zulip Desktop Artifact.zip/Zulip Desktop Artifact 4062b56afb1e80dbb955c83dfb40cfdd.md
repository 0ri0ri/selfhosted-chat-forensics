# Zulip Desktop Artifact

Status: Completed (Pending Additions)

## Zulip 이란?

Zulip은 팀 채팅 서비스이고, 데스크톱 클라이언트는 Electron으로 만들어졌다. Chromium 렌더러와 Node 주 프로세스가 한 앱에 들어 있다는 뜻이다. 사용자 데이터는 Windows에서 AppData/Roaming/Zulip 아래에 쌓인다. 이 앱은 앱 자체 설정을 config 폴더의 JSON으로 두고, 실제 서버 화면은 webview 파티션(Partitions/webviewsession) 아래 별도 Chromium 프로파일로 관리한다. 그래서 로그인 쿠키와 Local Storage와 캐시는 루트가 아니라 webviewsession 쪽에 남는다.

### **주요 특징**

- **Electron 기반 애플리케이션** : Chromium 렌더러를 내장해 웹 세션 흔적이 Chromium 저장소에 저장된다.
- **webview 파티션 분리(webviewsession)** : 서버 화면의 세션과 캐시가 루트가 아니라 Partitions/webviewsession에 남는다.
- **자체 호스팅 지원 (self-hosted)** : 접속한 서버 URL과 조직 별칭이 config/domain.json에 평문으로 남는다.
- **오류 보고 (Sentry)** : 환경 정보와 인앱 내비게이션이 sentry/scope_v3.json의 breadcrumb로 남는다.

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Zulip Desktop 5.13.2 (Electron 44.4.1, Chromium 152.0.7977.78, Node 24.21.0) |
| 설치 방식 | Desktop 설치형 (AppData/Local/Programs/Zulip, zulip-web-setup 설치) |
| OS / 버전 | Windows 11 26200, locale ko-KR, timezone Asia/Seoul |
| 샘플 수집 방법 | EWF/E01 디스크 이미지. 헤더에 FTK Imager ADI8.2.0.59, 획득 2026-10-25 |
| 계정 | 자체 호스팅 서버 zulip.lab의 테스트 계정으로 보인다 |

## 아티팩트 경로 및 설명(Zulip **Desktop**)

Zulip 데스크톱을 사용한 흔적은 %AppData%/Zulip에 존재한다. 아래의 경로에서 사용자의 흔적을 확인할 수 있다.

| 파일 경로 | 설명 |
| --- | --- |
| C:\Users\user\AppData\Roaming\Zulip\config\domain.json | 접속한 서버의 URL과 조직 별칭, 서버 버전과 기능 레벨이 평문 JSON으로 들어 있다. 어느 조직에 접속했는지를 바로 알 수 있다. |
| C:\Users\user\AppData\Roaming\Zulip\config\settings.json | 다운로드 폴더 경로와 알림, 자동 업데이트, 오류 보고 같은 앱 설정이 평문 JSON으로 남는다. |
| C:\Users\user\AppData\Roaming\Zulip\Partitions\webviewsession\Network\Cookies | 서버 로그인 세션 쿠키가 SQLite로 저장된다. 이 샘플에서는 CSRF와 세션 쿠키 값이 평문으로 남아 있다. |
| C:\Users\user\AppData\Roaming\Zulip\Partitions\webviewsession\Local Storage\leveldb\[0-9]{6}.log | 웹 UI 상태와 미전송 초안이 LevelDB 로그에 남는다. |
| C:\Users\user\AppData\Roaming\Zulip\Partitions\webviewsession\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index | 정적 자원과 사용자 아바타, server_settings 응답이 담기는 HTTP 캐시다. |
| C:\Users\user\AppData\Roaming\Zulip\sentry\scope_v3.json | 오류 보고용 환경 정보와 인앱 내비게이션 breadcrumb가 남는다. 어떤 채널과 주제를 열었는지 확인해 볼 수 있다. |
| C:\Users\user\AppData\Local\Programs\Zulip\* | 앱 실행 파일과 리소스가 설치되는 폴더이다. 앱 버전과 설치 사실을 확인하는 근거가 된다. |

### config\domain.json, setting.json 분석

2개의 json 파일에는 평문으로 앱 설정이 저장되어 있다. domain.json 파일에는 아래와 같이 서버와 조직에 대한 정보가 바로 보인다.

```json
{"domains":[{"url":"https://zulip.lab","alias":"zulip test",
  "zulipVersion":"12.3","zulipFeatureLevel":500}]}
```

setting.json 파일에는 다운로드 폴더 경로, 알림 등에 대한 앱 설정이 저장되어 있다. 

```json
{
	...
	"showNotification": true,
	"customCSS": false,
	"lastActiveTab": 0,
	"dnd": false,
	"dndPreviousSettings": {
	    "showNotification": true,
	    "silent": false,
	    "flashTaskbarOnMessage": true
	},
	"downloadsPath": "C:\\Users\\user\\Downloads",
	"quitOnClose": false,
	"promptDownload": false,
	"flashTaskbarOnMessage": true
}
```

### Partitions\webviewsession\Network\Cookies 분석

로그인 세션은 webviewsession의 쿠키에 있다. zulip.lab 호스트에 쿠키가 2개이고, 둘 다 value 컬럼에 평문 32자가 들어 있으며 encrypted_value는 비어 있었다. 즉 이 클라이언트는 쿠키는 암호화하지 않고 저장되어 있다.

![image.png](image.png)

| **필드** | **의미** | **샘플 값** |
| --- | --- | --- |
| host_key | 대상 호스트 | zulip.lab |
| name | 쿠키 이름 | __Host-csrftoken, __Host-sessionid |
| value | 평문 값 | Mw****(32자). 14****(32자) 마스킹 |
| encrypted_value | 암호문 | 0바이트(미사용) |
| is_httponly / is_secure | 보호 플래그 | 1 / 1 |
| creation_utc | 생성 시각(WebKit us) | 2026-10-25 09:01:51 UTC |

### Partitions\webviewsession\Local Storage\leveldb\[0-9]{6}.log 분석

local storage의 leveldb에는 미전송 메시지 또는 메시지 작성 초안이 저장되어 있다. 오류 소스코드를 수정한 ccl_chromium_reader 수정버전을 이용하여 leveldb 파일을 분석해 보면 아래와 같다.

![image.png](image%201.png)

초안이 빈 객체로 되어 있기 때문에 미전송 메시지도 없었던 것을 알 수 있다.

| **필드** | **의미** | **샘플 값** |
| --- | --- | --- |
| ls__1__drafts | 미전송 초안 | {"data":{},"__valid":true} 빈 객체 |
| ls__1__left_sidebar_collapsed_stream_sections | 사이드바 접힘 상태 | {"data":[]} |

### Partitions\webviewsession\Cache\Cache_Data\f_[0-9]{6}, data_[0-3], index 분석

Chromium 블록파일 캐시방식을 사용한다. 정적 자원(JS, CSS, 폰트, 이미지 등)과 사용자 아바타(user_avatars 경)가 존재한다. API 응답은 server_settings(조직 이름과 서버 버전이 든 JSON)와 json/events(롱폴 큐, 본문 0바이트) 그리고 대화방에서 업로드한 첨부파일의 썸네일이다. Chromium 캐시 분석 도구인 ChromeCacheView를 이용해서 분석을 진행해 보면 아래와 같다.

![image.png](image%202.png)

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| 캐시 엔트리 key | 캐시된 요청 URL | /api/v1/server_settings, /user_avatars, /user_uploads |
| 엔트리 creation_time | 응답을 받은 시각 | WebKit µs, KST 변환 |
| 첨부파일 (user_uploads) | 첨부한 파일의 썸네일 | 첨부 이미지 파일의 썸네일 webp 파일 |

### sentry\scope_v3.json 분석

errorReporting이 켜져 있어 Sentry의 상태가 디스크에 남는다. scope_v3.json에 환경 정보와 breadcrumb 데이터가 존재한다. 환경 정보에는 OS 버전, 로케일 ko-KR, 타임존 Asia/Seoul, 가상 GPU(VMware), 앱과 Chromium과 Node 버전이 저장되어 있다. breadcrumb에는 인앱 내비게이션이 남아 있다.

```
1792920279  https://zulip.lab/#channels/new
1792920731  https://zulip.lab/#narrow/channel/4-meating-room/topic//with/16
```

위 내용을 확인해 보면 채널 만들기 화면을 열고(18:24 KST), id 4인 채널 meating-room의 토픽을 열어 본(18:32 KST) 흔적이 존재한다. 계정 이메일이나 메시지 본문은 없었다.