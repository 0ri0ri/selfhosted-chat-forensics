# Rocket.Chat Server Artifact

Status: Completed (Pending Additions)

## Rocket.Chat Server 란?

Rocket.Chat은 Meteor(Node.js) 기반의 오픈 소스 메신저다. 조직이 직접 서버를 운영하는 자체 호스팅 형태로 많이 사용하고, 클라이언트는 웹 브라우저, 데스크톱 앱(Electron), 모바일 앱이 있다. 모든 클라이언트는 서버에 접속해 데이터를 받아 오므로, 대화의 원본은 서버의 MongoDB에 모인다. 대부분의 사람들은 공식 rocketchat-compose 저장소를 사용한다. compose가 띄우는 컨테이너는 rocketchat, mongodb(레플리카셋 rs0), nats, 두 개의 exporter이다.

MongoDB는 컬렉션 하나를 WiredTiger 테이블 파일 하나(collection-<UUID>.wt)로, 인덱스 하나를 index-<UUID>.wt로 저장한다. 파일 이름에 컬렉션 이름이 없으므로 대응표부터 찾아야 한다. 첨부 파일도 기본 설정(GridFS)이라 디스크의 일반 파일이 아니라 MongoDB 컬렉션 안에 있다.

### **주요 특징**

- **자체 호스팅 (Self-hosted)** : 메시지, 계정, 첨부가 모두 서버의 MongoDB 볼륨 하나에 남는다
- **GridFS 파일 저장 (GridFS upload storage)** : 첨부 원본이 rocketchat_uploads.chunks 컬렉션에 261,120바이트 조각으로 남는다
- **종단간 암호화 (End-to-End Encryption)** : 켠 방의 메시지와 첨부는 암호문으로, 키 재료는 users와 subscription에 남는다
- **휴지통 컬렉션 (Trash collection)** : 삭제한 문서가 rocketchat__trash에 삭제 시각과 함께 통째로 옮겨진다
- **레플리카셋 oplog (Replica set oplog)** : 모든 쓰기가 local.oplog.rs에 시각과 함께 남는다
- **감사 이벤트 (Server events)** : 로그인과 설정 변경이 IP와 함께 rocketchat_server_events에 남는다

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Rocket.Chat 8.9.0 (Node.js 24.15.0), MongoDB 8.2.12 (WiredTiger 12.0.0), NATS 2.11.17, Caddy v2.11.7 |
| 설치 방식 | 공식 rocketchat-compose 저장소를 docker compose로 실행 (compose.database.yml, compose.nats.yml, compose.yml), Caddy는 별도 docker run |
| OS / 버전 | Ubuntu 26.04.1 LTS, 커널 7.0.0-38-generic, VMware 가상머신, 시간대 Asia/Seoul |
| 샘플 수집 방법 | VM을 끈 뒤 VMDK를 FTK Imager로 E01 변환 (EWF 헤더 av=ADI8.2.0.59) |
| 계정 | 테스트 계정 rocket01(관리자), rocket02(일반), 기본 봇 rocket.cat |

## 아티팩트 경로 및 설명(**Rocket.Chat Server**)

Rocket.Chat Server는 거의 대부분 docker를 이용해서 운용하기 때문에 관련 흔적을 확인해 보면 아래와 같다.

| 파일 경로 | 설명 |
| --- | --- |
| /var/lib/docker/volumes/rocketchat-compose_mongodb_data/_data/ | Rocket.Chat의 모든 사용자 데이터가 들어 있는 MongoDB 데이터 디렉터리다. 컬렉션 하나가 collection-*.wt 파일 하나(109개)로, 인덱스가 index-*.wt(448개)로 저장되는데 파일 이름에 컬렉션 이름이 없어 _mdb_catalog.wt로 대응시켜야 한다. 계정, 방, 메시지, GridFS 첨부 원본, 로그인 IP와 클라이언트 기록이 모두 여기 있고, 레플리카셋 oplog와 journal/WiredTigerLog.*에는 지운 메시지와 첨부의 삭제 전 데이터까지 남는다. |
| /var/lib/docker/containers/<컨테이너 ID>/ | 컨테이너마다 폴더가 하나씩 생긴다. config.v2.json에는 컨테이너 이름, 이미지 태그, 생성과 시작 시각, 마운트, 환경 변수(ROOT_URL, MONGO_URL 등)가 JSON으로 남아 서버를 언제 어떤 구성으로 띄웠는지 알 수 있다. <ID>-json.log에는 컨테이너 표준 출력이 UTC 시각과 함께 쌓이며, 이 샘플에서는 서버 시작 배너, 계정 생성 때의 메일 오류, 라이선스 설치 기록이 남았다. |
| /home/rocket/rocketchat-compose/ | 공식 rocketchat-compose 저장소를 받은 폴더로, compose.yml, compose.database.yml, compose.nats.yml과 .env가 있다. .env에는 Rocket.Chat 버전(RELEASE=8.9.0), 외부 접속 주소(ROOT_URL), 바인드 IP와 포트가 적혀 있어 서버가 어떤 버전으로 어느 주소에서 서비스됐는지 알 수 있다. BIND_IP=0.0.0.0, HOST_PORT=3000을 사용자가 직접 덧붙인 명령은 .bash_history에 남았다. |

### **/var/lib/docker/volumes/rocketchat-compose_mongodb_data/_data/ 분석**

모든 사용자 데이터가 이 디렉터리에 있다. MongoDB를 분석하는 방법으로는 여러가지가 존재한다.

1. MongoDB을 Docker 또는 서버로 올려서 수집한 MongoDB 폴더를 이식시켜서 로드하는 방법
2. 수집한 MongoDB 폴더를 분석 도구에 넣어서 분석하는 방법

1번 방식이 일반적인 분석 방법이고, 2번은 현재 MongoDB 폴더를 input으로 받아서 분석해주는 도구가 없다. 그래서 임시로 사용할 MongoDB 분석 도구를 개발하였다. 해당 도구에 데이터를 넣어보면 아래와 같다.

위와 같이 무수히 많은 테이블이 존재하고 rocketchat_message 테이블에 다양한 데이터가 저장되어 있는데, 실제로 msg 칼럼을 확인해 보면 각 행마다 입력한 메시지를 확인해 볼 수 있다. 아래는 중요 테이블 관련 표이다.

![image.png](image.png)

다양한 컬렉션이 존재하기 때문에 핵심 컬렉션에 대한 내용을 다뤄보면 아래와 같다.

#### **컬렉션 카탈로그 (_mdb_catalog.wt, sizeStorer.wt)**

_mdb_catalog의 값은 ns(데이터베이스.컬렉션), ident(파일 이름), idxIdent(인덱스 파일), md(메타데이터)를 가진 BSON 레코드이다. 수많은 컬렉션 중에서 중요한 정보를 저장하고 있는 컬렉션은 아래와 같다.

- rocketchat.users : 계정
- rocketchat.rocketchat_room : 방
- rocketchat.rocketchat_subscription : 사용자별 방 참여
- rocketchat.rocketchat_message : 메시지
- rocketchat.rocketchat__trash : 삭제된 문서
- rocketchat.rocketchat_uploads (.files, .chunks) : 첨부 메타와 GridFS
- rocketchat.rocketchat_server_events : 로그인, 설정 변경 감사
- rocketchat.rocketchat_sessions : 세션, 기기, IP
- rocketchat.rocketchat_settings : 서버 설정
- local.oplog.rs : 레플리카셋 oplog

#### **사용자와 방 (users, rocketchat_room, rocketchat_subscription)**

rocketchat_room.lastMessage는 마지막 메시지 문서를 통째로 복사해 두므로, DM의 마지막 본문이 메시지 컬렉션 밖에 한 번 더 남는다. 방의 msgs는 삭제를 반영해 줄어든다.

![image.png](image%201.png)

![image.png](image%202.png)

| 컬렉션 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| users | _id, username, name | 계정 ID, 아이디, 표시 이름 | xTjYt***, rocket01, Test01 |
| users | emails[].address | 이메일 (검증 안 됨) | ji***@gmail.com |
| users | roles | 권한 | user, admin |
| users | createdAt, lastLogin | 생성, 마지막 로그인 (UTC datetime) | 2026-10-24 17:36:44 KST |
| users | services.password.bcrypt | 비밀번호 해시 | bcrypt 2b, cost 10, **** (60자) |
| users | services.resume.loginTokens[] | 로그인 토큰 (when, hashedToken) | token: ****(44자) |
| users | e2e.public_key, e2e.private_key | E2E 공개키(JWK), 비밀번호 유래 키로 암호화한 개인키 | 427자, 2376자 |
| users | statusConnection | 수집 직전 연결 상태 | rocket01 online, rocket02 offline |
| rocketchat_room | t | 방 유형 | c(공개), d(DM), p(비공개) |
| rocketchat_room | encrypted, e2eKeyId | E2E 방 여부와 키 ID | Trip: true |
| rocketchat_room | msgs, lm, lastMessage | 메시지 수, 마지막 메시지 시각, 마지막 메시지 사본 | DM: 8 |
| rocketchat_subscription | u, rid, ts, ls | 참여자, 방, 참여 시각, 마지막으로 본 시각 | DM의 rocket01 ls 2026-10-24 19:07:31 KST |
| rocketchat_subscription | E2EKey | 이 사용자 공개키로 암호화한 방 키 | 380자 |

#### **첨부 (rocketchat_uploads, .files, .chunks)**

FileUpload_Storage_Type 설정이 GridFS라 첨부는 MongoDB 안에 있다. rocketchat_uploads가 이름, 크기, 올린 사람, 방을, .files가 GridFS 파일 정보를, .chunks가 261,120바이트 단위 조각을 가진다.

![image.png](image%203.png)

#### **레플리카셋 oplog (local.oplog.rs)**

rocketchat DB가 아닌 local DB 내에 존재하는 oplog.rs 컬렉션에서 확인이 가능하다. oplog는 레플리카셋 복제를 위한 모든 쓰기 기록이다.

![image.png](image%204.png)

oplog는 서버 시작(2026-10-24 17:29:44 KST)부터 마지막 쓰기(2026-10-25 14:36:06 KST)까지 끊김 없이 남았다. 크기가 15 MB 정도라 상한에 닿지 않았기 때문이고, 운영 서버에서는 오래된 항목이 밀려날 것으로 보인다. 메시지 insert는 문서 전체를, GridFS 청크 insert는 파일 바이트 전체를 담고 있어서, 컬렉션에서 지워진 데이터도 여기서 다시 꺼낼 수 있다.

#### **휴지통 (rocketchat__trash)**

Rocket.Chat 모델 계층은 문서를 지우기 전에 원래 문서에 _deletedAt과 __collection__을 붙여 휴지통 컬렉션에 upsert한다.

![image.png](image%205.png)

| 컬렉션 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| rocketchat__trash | _id | 원래 메시지 _id | daBEKzRJcCAJBxBaT |
| rocketchat__trash | __collection__ | 원래 모델 이름 | message |
| rocketchat__trash | _deletedAt | 삭제 시각 | 2026-10-24 19:10:58.056 KST |
| rocketchat__trash | rid, u, ts, content | 방, 보낸 사람, 보낸 시각, E2E 암호문 | Trip, rocket01 |
| rocketchat__trash | attachments[].fileId, size | 지워진 첨부 ID, 크기 | 6adc8425..., 359968 |

#### **서버 이벤트와 세션 (rocketchat_server_events, rocketchat_sessions)**

rocket01은 192.168.6.1에서 Chrome으로, rocket02는 192.168.6.132에서 데스크톱 앱으로 접속했다. 192.168.6.1은 VMware NAT 망의 호스트 쪽 주소로 보인다.

![image.png](image%206.png)

![image.png](image%207.png)

| 컬렉션 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| server_events | t | 이벤트 종류 | login, settings.changed |
| server_events | ts, ip, u | 시각, 요청 IP, 사용자 | 192.168.6.1 rocket01 |
| server_events | data | 설정 변경 전후 값 (비밀값은 서버가 * 로 가려 저장) | E2E_Enable false → true |
| sessions | loginAt, lastActivityAt, closedAt | 세션 시작, 마지막 활동, 종료 |  |
| sessions | device.name, device.type, device.os | 클라이언트 | Chrome browser Windows 10, Rocket.Chat desktop-app Windows 10 |
| sessions | ip, host | 접속 IP, 접속한 서버 주소 | 192.168.6.132, 192.168.6.133 |

### **/var/lib/docker/containers/<컨테이너 ID>/ 분석**

config.v2.json은 컨테이너 이름, 이미지 태그, Created, State.StartedAt, MountPoints를 담는다. 컨테이너 6개가 모두 Running true, FinishedAt 0001-01-01로 남아 있어, 컨테이너가 정상 정지되지 않은 채 꺼진 것을 알 수 있다. json-file 로그는 한 줄에 log, stream, time을 가진 JSON이다.

- **rocketchat 로그(74줄)** : 서버 시작 배너(Rocket.Chat 8.9.0, MongoDB 8.2.12), 계정 생성 때 메일 서버 미설정 오류(17:36:45 KST), 라이선스 설치(17:37:59 KST)가 남았다.
- **mongod 로그(구조화 로그 58,993줄)** : 대부분 내부 mongosh 접속이다. 마지막 줄은 NUL 2,520바이트로 채워져 있다.
- **caddy 로그(49줄)** : 인증서 발급과 갱신, 프록시 오류 1건(클라이언트 192.168.6.1)뿐이다. Caddyfile에 log 지시어가 없어 요청별 접근 로그는 남지 않는다.