# Mattermost Server Artifact

Status: Completed (Pending Additions)

## Mattermost란?

Mattermost는 자체 호스팅 팀 메신저이다. 서버 중심 구조로 메시지 원본과 파일, 세션을 서버의 PostgreSQL과 파일 저장소가 보관하고, 클라이언트(Electron 데스크톱 앱과 웹 브라우저)는 서버에서 받아 화면에 보여 준다. 서버는 Go로 작성된 단일 바이너리이며 PostgreSQL 또는 MySQL을 사용한다.  종단간 암호화(E2EE)가 없기 때문에 서버 관리자나 서버 디스크를 가진 사람은 Private 채널과 DM까지 모두 평문으로 읽을 수 있다.

### **주요 특징**

- **서버 중심 구조 (Server-centric)** : 메시지 정본과 파일을 서버가 보관하므로, 서버 DB 하나에 조직 전체 대화가 평문으로 남는다.
- **종단간 암호화 없음 (No E2EE)** : Private 채널과 DM도 서버에 평문으로 저장돼, 서버 디스크를 가진 사람이 전부 읽을 수 있다.
- **Go 단일 바이너리 + 관계형 DB (PostgreSQL/MySQL)** : 최신버전 에서는 PostgreSQL 17을 쓰고, 클러스터 heap 파일에서 직접 메시지가 복원된다.
- **Electron 데스크톱 앱 (Electron)** : Chromium 기반이라 LevelDB, IndexedDB, Chromium HTTP 캐시에 상태와 대화 일부가 남는다.
- **웹 클라이언트 (Web)** : 브라우저 History, Cookies, Cache에 접속 이력과 받은 대화 일부가 남는다.

## 분석 대상 환경

분석에 사용한 환경은 아래와 같다.

| 항목 | 값 |
| --- | --- |
| 앱 / 버전 | Mattermost Server 12.0.1 Team Edition (build 39742891057, 2026-10-22), go1.26.10 |
| 설치 방식 | 서버 tarball 설치 (/opt/mattermost) |
| OS / 버전 | Ubuntu 22.04 LTS |
| DB / 저장 | PostgreSQL 17, DB 이름 mattermost_test, 파일저장 local (/opt/mattermost/data) |
| 샘플 수집 방법 | FTK Imager로 오프라인(dead) 디스크 이미징(E01). ext4 볼륨 |
| 계정 | 테스트 계정 2개. alex (system_admin), natasha (일반)가 대화 |

## 아티팩트 경로 및 설명(**Mattermost Server**)

서버에서 볼 경로는 아래와 같다. 메시지의 원본은 PostgreSQL에 모이고, 업로드된 파일은 디스크에 원본 그대로 저장되며, 서버 설정과 접속 정보는 config.json에, 버전과 기동 흔적은 로그에 남는다.

| 파일 경로 | 설명 |
| --- | --- |
| /opt/mattermost/config/config.json | 서버 설정 파일이다. 데이터베이스 접속 문자열과 공개 주소(SiteURL)를 비롯한 서버 구성이 들어 있어, 분석 대상 DB와 서비스 주소를 여기서 확인한다. |
| PostgreSQL 데이터베이스 (mattermost_test) | 메시지, 채널, 사용자, 파일 메타데이터, 세션, 감사 로그의 원본이 모이는 핵심 저장소다. 클라이언트가 지운 메시지도 여기서는 평문으로 복원된다. |
| /var/lib/postgresql/17/main/base | PostgreSQL이 실제로 쓰는 라이브 클러스터 파일(heap)이다. pg_dump가 없어도 이 파일에서 직접 메시지 평문을 꺼낼 수 있다. |
| /opt/mattermost/data | 업로드된 파일의 원본과 파생물이 그대로 저장된다. 첨부 원본, 이미지 썸네일과 미리보기, 프로필 사진, 커스텀 이모지가 날짜와 채널별 경로에 남는다. |
| /opt/mattermost/logs/mattermost.log | 서버 운영 로그로 서버 버전과 기동 시각을 확인할 수 있다. |

### config.json 분석

어떤 데이터베이스를 어떤 드라이버로 사용하고 있으며, 파일을 어디에 저장하고, 서비스 주소가 무엇인지에 대한 정보가 평문으로 저장되어 있다. 해당 설정파일에서 분석 대상 db 이름과 파일 저장방식, 서버 공개 주소 등을 확인한다.

```jsx
{ "version": 4,
  "servers": [ { "name": "RESEARCH", "url": "http://192.168.156.134:8065/", "order": 0 } ],
  "lastActiveServer": 0, "downloadLocation": "C:\\Users\\user\\Downloads" }
```

| 키 | 의미 | 샘플 값 |
| --- | --- | --- |
| ServiceSettings.SiteURL | 서버 공개 주소 | http://192.168.156.134:8065 |
| SqlSettings.DriverName | DB 드라이버 | postgres |
| SqlSettings.DataSource | DB 접속 문자열 (비밀번호 가림) | postgres://mmuser:****@localhost/mattermost_test |
| FileSettings.DriverName | 파일 저장 방식 | local |

### **PostgreSQL 데이터베이스 분석**

메시지를 비롯한 거의 모든 원본 데이터가 모이는 핵심 저장소다. 채널, 사용자, 파일 메타데이터, 세션, 감사 로그가 함께 들어 있고, 메시지는 posts 테이블에 담긴다. pg_dump로 뽑은 논리 백업에서 posts 테이블의 필드 구성을 보면 아래와 같다.

PostgreSQL은 단일 파일로 데이터를 저장하는 것이 아니기 때문에 pg_dump 명령어로 추출한 내용 또는 PostgreSQL 폴더를 확보한 후 Docker 또는 PostgreSQL 서비스를 통해 특정 버전을 잘 맞춰서 이식시키면 분석을 할 수 있다. (아티팩트 수집전 아래 명령어를 통해 SQL 파일을 생성하였다.)

pg_dump 명령어 : `sudo -u postgres pg_dump mattermost_test > mattermost_full.sql`(mattermost_test 가 DB 명)

| 테이블/키 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| posts | message | 메시지 본문 (평문) | 테스트 문장 |
| posts | createat / updateat / editat / deleteat | 생성/수정/편집/삭제 시각 | Unix 밀리초 |
| posts | userid / channelid | 작성자, 채널 | 26자 ID |
| posts | rootid | 스레드 루트 글 ID (답글이면 설정) | 26자 ID 또는 빈값 |
| posts | originalid | 편집 전 원본을 가리키는 ID | 26자 ID 또는 빈값 |
| posts | type | 시스템 메시지 종류 | system_join_channel, me 등 |
| posts | ispinned | Pin 여부 | t 또는 f |
| posts | props | 부가 메타 (멘션 등) | JSON |

분석 대상 노드의 PostgreSQL 내 posts 79행 중 삭제(deleteat > 0)가 3행, 편집(editat > 0)이 1행, Pin이 1행이었다. 삭제 3행 중 1행은 실제 사용자 삭제(TESTCASE-DEL)이고, 2행은 편집과 Pin 과정에서 생긴 보존 원본이다.

### **라이브 클러스터 파일(/var/lib/postgresql) 분석**

pg_dump 같은 논리 백업이 없어도, PostgreSQL이 실제로 쓰는 클러스터 파일(heap)에서 바이트를 직접 읽어 같은 메시지를 복원할 수 있다. 예제 분석 데이터에서 핵심 데이터가 담겨져 있는 posts 테이블은 DB oid 16390의 relfilenode 17010 파일에 들어 있다. 삭제된 메시지가 heap 페이지 안에 평문으로 남아 있는 모습을 확인해 볼 수 있으며 deleteat에 삭제 시각이 찍혀 있어도 message 바이트는 그대로 존재한다.

분석 방법으로는 앞에서 이야기한 것 처럼 방법은 여러가지가 존재한다.

1. PostgreSQL을 Docker 또는 서버로 올려서 수집한 PostgreSQL 폴더를 이식시켜서 로드하는 방법
2. 수집한 PostgreSQL 폴더를 분석 도구에 넣어서 분석하는 방법

1번 방식이 일반적인 분석 방법이고, 2번은 현재 PostgreSQL 폴더를 input으로 받아서 분석해주는 도구가 없다. 그래서 임시로 사용할 PostgreSQL DB 분석 도구를 개발하였다. 해당 도구에 데이터를 넣어보면 아래와 같다.

![image.png](image.png)

위와 같이 posts 테이블에 다양한 데이터가 저장되어 있는데, 실제로 message 칼럼을 확인해 보면 각 행마다 입력한 메시지가 있는 것을 알 수 있다.

![image.png](image%201.png)

또한 수정된 메시지는 삭제된 메시지로 표현되며, 삭제된 시간이 작성되어 있고, originalid 값이 존재한다. 삭제된 메시지는 삭제된 시간은 있으나 originalid 값이 없고, props 칼럼에 “{"deleteBy":"wbg5za8it7grjr9g571ids9ooe","disable_group_highlight":true}”와 같이 deleteBy 값이 포함되어 어떤 사용자가 삭제했는지 알 수 있다.

### /opt/mattermost/data 분석

업로드 파일의 원본이 그대로 존재한다. 경로는 날짜, 팀, 채널, 사용자, 파일ID 순으로 구성되어 있기 때문에, 파일 경로만 봐도 어떤 사용자가 어떤 채널에서 언제 업로드한 파일인지 확인할 수 있다.

```jsx
data/20261023/teams/noteam/channels/<channelID>/users/<userID>/<fileID>/test_photo_01.png
data/20261023/teams/noteam/channels/<channelID>/users/<userID>/<fileID>/test_photo_02_thumb.jpg
data/emoji/<emojiID>/image
data/users/<userID>/profile.png
```

| 테이블/키 | 필드 | 의미 | 샘플 값 |
| --- | --- | --- | --- |
| fileinfo | path | 원본 파일 디스크 경로 | 위 구조 |
| fileinfo | thumbnailpath / previewpath | 이미지 썸네일, 미리보기 경로 | _thumb, _preview |
| fileinfo | name / extension / size / mimetype | 파일 이름, 크기, MIME | test_photo_01.png, image/png, 10140 |

이미지 업로드 시 원본과 함께 _thumb, _preview가 자동 생성된다. 텍스트와 PDF의 경우에는 썸네일이 없다. DM이나 팀 없는 채널의 파일은 teams 아래 noteam에 저장되며, fileinfo 행과 디스크 경로가 맞물려, 어떤 메시지에 어떤 파일이 붙었는지까지 이어 붙일 수 있다.

### /opt/mattermost/logs/mattermost.log 분석

서버 운영 로그이다. 서버를 기동할 때마다 버전과 빌드가 기록되어 있다. 설정파일을 읽어 들인 시각과 DB 접속 과정도 남아 서버가 언제 떴는지 가늠할 수 있다. 접속 문자열이 로그에도 존재하며, 비밀번호의 경우 마스킹되어 기록된다.

| 필드 | 의미 | 샘플 값 |
| --- | --- | --- |
| current_version / build_number | 서버 버전과 빌드 번호 | 12.0.1, 39742891057 |
| enterprise_build | 엔터프라이즈 여부 | false (Team Edition) |
| msg Loaded config | 설정 파일 로드 시각 | 기동 타임라인의 기준점 |